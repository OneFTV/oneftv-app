# Proposta Revisada: Sistema Multi-Categoria para Torneios de Futevôlei

**Versão:** 2.0 — Revisão completa com feedback do stakeholder
**Data:** 2026-02-13
**Escopo:** TAFC / LBF / NFA + Comercial + Operação + Backoffice

---

## Índice

1. [Visão Geral da Arquitetura](#1-visão-geral-da-arquitetura)
2. [Modelos de Dados (Prisma Schema)](#2-modelos-de-dados-prisma-schema)
3. [Regras de Negócio Críticas](#3-regras-de-negócio-críticas)
4. [Sistema Comercial (Inscrição + Pagamento)](#4-sistema-comercial)
5. [Operação de Evento](#5-operação-de-evento)
6. [Página Pública do Evento](#6-página-pública-do-evento)
7. [Backoffice / Dashboards](#7-backoffice--dashboards)
8. [Templates de Evento](#8-templates-de-evento)
9. [Fluxos UX Detalhados](#9-fluxos-ux-detalhados)
10. [Migração e Backward Compatibility](#10-migração-e-backward-compatibility)
11. [Segurança e Requisitos Não-Funcionais](#11-segurança-e-requisitos-não-funcionais)
12. [Fases de Implementação](#12-fases-de-implementação)

---

## 1. Visão Geral da Arquitetura

### Hierarquia Central

```
Event (Tournament)                    ← Container da etapa/evento
 ├── EventPolicy                      ← Regras: reembolso, multi-categoria, termos
 ├── Category[]                       ← Mini-torneios independentes
 │    ├── PricingLot[]                ← Lotes de venda por categoria
 │    ├── TeamRegistration[]          ← Inscrições de duplas
 │    │    ├── Order                  ← Pedido/checkout
 │    │    │    └── PaymentTransaction[] ← Transações
 │    │    └── CheckIn                ← QR code + presença
 │    ├── Group[]                     ← Fase de grupos
 │    ├── Round[]                     ← Rodadas
 │    └── Game[]                      ← Jogos/partidas
 └── ScheduleSlot[]                   ← Programação oficial por dia/quadra
```

### Princípio de Design

- **Event** = dados logísticos compartilhados (local, datas, quadras, organização)
- **Category** = cada uma é um mini-torneio autônomo com seu formato, regras, jogadores e chave
- **Tudo que é competitivo pertence a Category**, não ao Event

### O que muda vs. sistema atual

| Hoje | Proposta |
|------|----------|
| `Tournament` = 1 formato, 1 chave, 1 grupo de jogadores | `Tournament` = container com N categorias |
| `format`, `maxPlayers`, `pointsPerSet` no Tournament | Esses campos migram para `Category` |
| Games/Groups/Rounds pertencem ao Tournament | Passam a pertencer a uma `Category` |
| Sem pagamento, sem check-in, sem lotes | Sistema comercial completo |
| Atleta se inscreve sozinho (individual) | Inscrição por dupla (TeamRegistration) |

---

## 2. Modelos de Dados (Prisma Schema)

### 2.1 Tournament (evolução — vira container de evento)

```prisma
model Tournament {
  id              String    @id @default(cuid())
  name            String                            // "TAFC #52 - João Pessoa"
  description     String?   @db.Text
  date            DateTime                          // Início do evento
  endDate         DateTime?
  location        String                            // Nome do local
  city            String?
  state           String?
  country         String?
  status          String    @default("draft") @db.VarChar(20)
                                                    // draft | registration | in_progress | completed | cancelled
  numCourts       Int       @default(1)
  numDays         Int       @default(1)
  hoursPerDay     Float     @default(8)
  bannerUrl       String?   @db.Text                // Banner/imagem do evento
  instagramUrl    String?                           // Instagram do evento
  websiteUrl      String?                           // Site oficial
  organizerId     String
  createdAt       DateTime  @default(now())
  updatedAt       DateTime  @updatedAt

  // ── Políticas do Evento ──
  allowMultiCategory    Boolean @default(false)     // Pode inscrever em N categorias?
  maxCategoriesPerAthlete Int?                      // Limite (null = sem limite se allowMultiCategory=true)
  refundPolicy          String? @db.Text            // Política de reembolso (texto livre)
  termsUrl              String?                     // Link para regulamento completo
  supportEmail          String?                     // Email de suporte
  supportPhone          String?                     // WhatsApp/telefone de suporte

  // ── Relations ──
  organizer       User            @relation("Organizer", fields: [organizerId], references: [id])
  categories      Category[]
  scheduleSlots   ScheduleSlot[]

  // ── Campos legados (mantidos para backward compat, nullable) ──
  format          String?   @db.VarChar(30)
  maxPlayers      Int?
  avgGameMinutes  Int?
  pointsPerSet    Int?
  numSets         Int?
  groupSize       Int?
  proLeague       Boolean?

  // ── Legado: relações diretas (mantidas para torneios antigos sem categoria) ──
  players         TournamentPlayer[]
  groups          Group[]
  games           Game[]
  rounds          Round[]

  @@index([organizerId])
  @@index([status])
  @@index([date])
}
```

### 2.2 Category (NOVO — núcleo competitivo)

```prisma
model Category {
  id              String    @id @default(cuid())
  tournamentId    String
  name            String                            // "Profissional Masculino"
  description     String?   @db.Text
  sortOrder       Int       @default(0)             // Ordem de exibição

  // ── Classificação ──
  gender          String    @db.VarChar(10)         // men | women | mixed | open
  skillLevel      String    @db.VarChar(20)         // beginner | intermediate | advanced | pro | open
  ageGroup        String?   @db.VarChar(20)         // open | u18 | u21 | master40 | master45 | master50

  // ── Formato competitivo ──
  format          String    @db.VarChar(30)         // bracket | group_knockout | round_robin | king_of_the_beach
  maxTeams        Int       @default(16)            // Máximo de duplas
  pointsPerSet    Int       @default(18)
  numSets         Int       @default(1)
  groupSize       Int       @default(4)
  avgGameMinutes  Int       @default(20)
  proLeague       Boolean   @default(false)         // Best-of-3 em semis/final
  netHeight       Float?                            // 2.20 homens, 2.10 mulheres (metros)

  // ── Classificatória (Qualify → Principal) ──
  isQualifier     Boolean   @default(false)
  qualifiesForId  String?                           // ID da categoria destino
  advanceCount    Int?                              // Quantos classificam

  // ── Validação técnica ──
  requiresLevelReview  Boolean @default(false)      // Exige aprovação de nível?

  // ── Status ──
  status          String    @default("draft") @db.VarChar(20)
                                                    // draft | registration | in_progress | completed | cancelled
  createdAt       DateTime  @default(now())
  updatedAt       DateTime  @updatedAt

  // ── Relations ──
  tournament        Tournament         @relation(fields: [tournamentId], references: [id], onDelete: Cascade)
  qualifiesFor      Category?          @relation("QualifierChain", fields: [qualifiesForId], references: [id])
  qualifiers        Category[]         @relation("QualifierChain")
  pricingLots       PricingLot[]
  teamRegistrations TeamRegistration[]
  players           TournamentPlayer[]
  groups            Group[]
  rounds            Round[]
  games             Game[]

  @@index([tournamentId])
  @@index([qualifiesForId])
  @@index([status])
}
```

### 2.3 TeamRegistration (NOVO — inscrição por dupla)

```prisma
model TeamRegistration {
  id              String    @id @default(cuid())
  categoryId      String
  player1Id       String                            // Atleta 1
  player2Id       String                            // Atleta 2
  teamName        String?                           // Nome da dupla (opcional)
  seed            Int?                              // Cabeça de chave

  // ── Validação de nível técnico ──
  reviewStatus    String    @default("auto_approved") @db.VarChar(20)
                                                    // auto_approved | pending_review | approved | reallocated | rejected
  reviewNotes     String?   @db.Text
  reviewedBy      String?                           // ID do revisor
  reviewedAt      DateTime?
  reallocatedToId String?                           // Se realocado, para qual categoria?

  // ── Comercial ──
  orderId         String?   @unique
  pricingLotId    String?                           // Qual lote usou

  // ── Status geral ──
  status          String    @default("pending_payment") @db.VarChar(20)
                                                    // pending_payment | confirmed | checked_in | cancelled | no_show
  createdAt       DateTime  @default(now())
  updatedAt       DateTime  @updatedAt

  // ── Relations ──
  category        Category      @relation(fields: [categoryId], references: [id], onDelete: Cascade)
  player1         User          @relation("TeamPlayer1", fields: [player1Id], references: [id])
  player2         User          @relation("TeamPlayer2", fields: [player2Id], references: [id])
  order           Order?        @relation(fields: [orderId], references: [id])
  pricingLot      PricingLot?   @relation(fields: [pricingLotId], references: [id])
  reallocatedTo   Category?     @relation("Reallocation", fields: [reallocatedToId], references: [id])
  checkIn         CheckIn?

  @@unique([categoryId, player1Id, player2Id])
  @@index([categoryId])
  @@index([player1Id])
  @@index([player2Id])
  @@index([status])
  @@index([reviewStatus])
}
```

### 2.4 PricingLot (NOVO — lotes de venda por categoria)

```prisma
model PricingLot {
  id              String    @id @default(cuid())
  categoryId      String
  name            String                            // "1º Lote", "2º Lote", "Lote Final"
  price           Int                               // Centavos (ex: 15000 = R$150,00)
  currency        String    @default("BRL") @db.VarChar(3)
  platformFee     Int       @default(0)             // Taxa da plataforma (centavos)
  maxQuantity     Int                               // Estoque do lote
  soldCount       Int       @default(0)             // Vendidos até agora
  sortOrder       Int       @default(0)             // Prioridade de exibição

  // ── Janela de venda ──
  startsAt        DateTime
  endsAt          DateTime
  status          String    @default("scheduled") @db.VarChar(20)
                                                    // scheduled | active | sold_out | closed
  createdAt       DateTime  @default(now())
  updatedAt       DateTime  @updatedAt

  // ── Relations ──
  category        Category           @relation(fields: [categoryId], references: [id], onDelete: Cascade)
  registrations   TeamRegistration[]

  @@index([categoryId])
  @@index([status])
}
```

### 2.5 Order (NOVO — pedido/checkout)

```prisma
model Order {
  id                String    @id @default(cuid())
  userId            String                          // Quem está pagando
  totalAmount       Int                             // Centavos
  platformFee       Int       @default(0)           // Taxa da plataforma
  currency          String    @default("BRL") @db.VarChar(3)
  status            String    @default("pending") @db.VarChar(20)
                                                    // pending | processing | paid | failed | refunded | partially_refunded
  installments      Int       @default(1)           // Parcelas (1-12)

  // ── Política aplicável no momento da compra ──
  refundPolicySnapshot String? @db.Text             // Snapshot da política vigente

  // ── Idempotência ──
  idempotencyKey    String?   @unique               // Para evitar pagamento duplicado

  createdAt         DateTime  @default(now())
  updatedAt         DateTime  @updatedAt

  // ── Relations ──
  user              User              @relation(fields: [userId], references: [id])
  transactions      PaymentTransaction[]
  registration      TeamRegistration?

  @@index([userId])
  @@index([status])
}
```

### 2.6 PaymentTransaction (NOVO — trilha de pagamento)

```prisma
model PaymentTransaction {
  id                String    @id @default(cuid())
  orderId           String
  externalId        String?                         // ID do gateway (Stripe, PagSeguro, etc.)
  type              String    @db.VarChar(20)       // charge | refund | chargeback
  amount            Int                             // Centavos
  status            String    @db.VarChar(20)       // pending | succeeded | failed | reversed
  gatewayProvider   String?   @db.VarChar(30)       // stripe | pagseguro | mercadopago | pix
  gatewayResponse   String?   @db.Text              // JSON raw do gateway
  processedAt       DateTime?
  createdAt         DateTime  @default(now())

  // ── Relations ──
  order             Order     @relation(fields: [orderId], references: [id], onDelete: Cascade)

  @@index([orderId])
  @@index([externalId])
  @@index([status])
}
```

### 2.7 CheckIn (NOVO — QR code + presença)

```prisma
model CheckIn {
  id                  String    @id @default(cuid())
  teamRegistrationId  String    @unique
  qrCode              String    @unique             // UUID ou hash para QR
  player1CheckedIn    Boolean   @default(false)
  player2CheckedIn    Boolean   @default(false)
  player1CheckedInAt  DateTime?
  player2CheckedInAt  DateTime?
  checkedInBy         String?                       // Staff que fez check-in

  // ── Kit delivery ──
  kitDelivered        Boolean   @default(false)
  kitDeliveredAt      DateTime?
  kitNotes            String?   @db.Text            // "Camisa M + Boné"

  createdAt           DateTime  @default(now())
  updatedAt           DateTime  @updatedAt

  // ── Relations ──
  registration        TeamRegistration @relation(fields: [teamRegistrationId], references: [id], onDelete: Cascade)

  @@index([qrCode])
}
```

### 2.8 ScheduleSlot (NOVO — programação oficial por dia/quadra)

```prisma
model ScheduleSlot {
  id              String    @id @default(cuid())
  tournamentId    String
  categoryId      String?                           // null = slot geral (abertura, cerimônia)
  courtNumber     Int?                              // null = todas as quadras
  dayNumber       Int                               // Dia 1, 2, 3, 4...
  startTime       DateTime
  endTime         DateTime
  label           String                            // "Qualify Masculino - Fase de Grupos"
  type            String    @db.VarChar(20)         // competition | ceremony | break | warmup
  notes           String?   @db.Text

  createdAt       DateTime  @default(now())
  updatedAt       DateTime  @updatedAt

  // ── Relations ──
  tournament      Tournament @relation(fields: [tournamentId], references: [id], onDelete: Cascade)

  @@index([tournamentId])
  @@index([dayNumber])
}
```

### 2.9 AuditLog (NOVO — trilha de auditoria)

```prisma
model AuditLog {
  id              String    @id @default(cuid())
  userId          String?                           // Quem fez a ação (null = sistema)
  action          String    @db.VarChar(50)         // category.update | review.approve | refund.process
  entityType      String    @db.VarChar(30)         // tournament | category | registration | order
  entityId        String
  details         String?   @db.Text                // JSON com before/after
  ipAddress       String?
  createdAt       DateTime  @default(now())

  @@index([entityType, entityId])
  @@index([userId])
  @@index([createdAt])
}
```

### 2.10 WaitlistEntry (NOVO — lista de espera)

```prisma
model WaitlistEntry {
  id              String    @id @default(cuid())
  categoryId      String
  player1Id       String
  player2Id       String
  position        Int                               // Posição na fila
  status          String    @default("waiting") @db.VarChar(20)
                                                    // waiting | notified | converted | expired
  notifiedAt      DateTime?
  expiresAt       DateTime?                         // Prazo para confirmar após notificação
  createdAt       DateTime  @default(now())

  @@unique([categoryId, player1Id, player2Id])
  @@index([categoryId, status])
}
```

### 2.11 Alterações em Models Existentes

**User — novos campos e relations:**
```prisma
model User {
  // ... campos existentes ...
  cpf               String?   @unique              // Documento (validação de duplicidade)
  documentType      String?   @db.VarChar(20)      // cpf | passport | ssn | other
  documentNumber    String?                         // Número genérico
  dateOfBirth       DateTime?                       // Para categorias por idade (Master 45+)

  // Novas relations
  teamRegistrations1  TeamRegistration[] @relation("TeamPlayer1")
  teamRegistrations2  TeamRegistration[] @relation("TeamPlayer2")
  orders              Order[]
}
```

**TournamentPlayer — ganha categoryId:**
```prisma
model TournamentPlayer {
  // ... campos existentes ...
  categoryId        String?
  teamRegistrationId String?                        // Link para a dupla

  category          Category? @relation(fields: [categoryId], references: [id])
  @@index([categoryId])
}
```

**Group, Round, Game — ganham categoryId:**
```prisma
// Cada um recebe:
categoryId    String?
category      Category? @relation(fields: [categoryId], references: [id])
@@index([categoryId])
```

---

## 3. Regras de Negócio Críticas

### 3.1 Política de Múltiplas Categorias

```
┌─────────────────────────────────────────────────────────────┐
│  Configuração por Evento (Tournament)                       │
│                                                             │
│  allowMultiCategory = false (padrão)                        │
│    → Atleta pode estar em NO MÁXIMO 1 categoria             │
│    → Tentativa de 2ª inscrição: BLOQUEIO                    │
│    → Mensagem: "Este evento permite apenas 1 categoria      │
│      por atleta. Cancele sua inscrição atual primeiro."      │
│                                                             │
│  allowMultiCategory = true                                  │
│    maxCategoriesPerAthlete = null → sem limite               │
│    maxCategoriesPerAthlete = 2   → máximo 2 categorias      │
│                                                             │
│  Validação é feita por:                                     │
│    1. userId (logged in user)                               │
│    2. CPF/documento (para impedir conta duplicada)           │
│       → Se CPF do User A = CPF do User B, ambos contam     │
│         como mesmo atleta                                   │
└─────────────────────────────────────────────────────────────┘
```

**Implementação:**
```typescript
async function validateMultiCategoryPolicy(
  tournamentId: string,
  playerId: string,
  targetCategoryId: string
): Promise<{ allowed: boolean; reason?: string }> {
  const tournament = await getTournament(tournamentId);
  const playerDoc = await getPlayerDocument(playerId); // CPF ou documento

  // Buscar todas inscrições do atleta neste evento (por userId E por CPF)
  const existingRegistrations = await getRegistrationsByAthleteInEvent(
    tournamentId, playerId, playerDoc?.cpf
  );

  // Filtrar apenas confirmadas/pagas (não contar canceladas)
  const activeRegistrations = existingRegistrations.filter(
    r => !['cancelled', 'rejected'].includes(r.status)
  );

  if (!tournament.allowMultiCategory && activeRegistrations.length > 0) {
    return {
      allowed: false,
      reason: 'Este evento permite apenas 1 categoria por atleta.'
    };
  }

  if (tournament.maxCategoriesPerAthlete &&
      activeRegistrations.length >= tournament.maxCategoriesPerAthlete) {
    return {
      allowed: false,
      reason: `Limite de ${tournament.maxCategoriesPerAthlete} categorias atingido.`
    };
  }

  // Verificar se já está nesta categoria específica
  const alreadyInCategory = activeRegistrations.some(
    r => r.categoryId === targetCategoryId
  );
  if (alreadyInCategory) {
    return { allowed: false, reason: 'Atleta já inscrito nesta categoria.' };
  }

  return { allowed: true };
}
```

### 3.2 Validação de Nível Técnico

```
Fluxo de revisão (quando category.requiresLevelReview = true):

  Inscrição criada
       │
       ▼
  ┌─────────────────┐
  │  pending_review  │  ← Inscrição paga mas aguarda validação
  └────────┬────────┘
           │
     ┌─────┼──────────────┐
     ▼     ▼              ▼
 approved  reallocated   rejected
     │         │              │
     │    Movido para     Reembolso
     │    outra categoria  conforme
     │    (ex: Pro → Int)  política
     ▼
  confirmed
```

**Quem revisa:** Organizador ou árbitro designado via dashboard.

**Regras:**
- `auto_approved` = padrão quando `requiresLevelReview = false`
- `pending_review` = inscrição paga mas precisa de aprovação manual
- `reallocated` = atleta foi reclassificado para outra categoria (com notificação)
- `rejected` = atleta não atende critérios; reembolso segue `refundPolicy` do evento
- Toda ação de review gera entrada no `AuditLog`

### 3.3 Violação de Política (Não-Reembolso)

Quando um atleta viola regras (ex: tenta burlar single-category via conta duplicada):

```
Order.status = "paid"
Registration.status = "cancelled"
Registration.reviewStatus = "rejected"
Registration.reviewNotes = "Violação de política: duplicidade de inscrição por CPF"

→ AuditLog registra ação
→ Reembolso NÃO é processado (conforme refundPolicy)
→ refundPolicySnapshot no Order garante transparência
```

### 3.4 Cadeia Qualify → Principal

```
Qualify Masculino (isQualifier=true, qualifiesForId=proMascId, advanceCount=8)
       │
       │  Quando status = "completed":
       │  Top 8 classificados são promovidos automaticamente
       │
       ▼
Profissional Masculino
       │
       │  Sistema cria TeamRegistration com:
       │    status = "confirmed"
       │    reviewStatus = "auto_approved"
       │    orderId = null (sem cobrança adicional)
       │
       ▼
  Organizador pode adicionar convidados/cabeças manualmente
```

---

## 4. Sistema Comercial

### 4.1 Modelo de Preço

```
Preço final = PricingLot.price + PricingLot.platformFee

Exemplo TAFC #52:
  Profissional Masculino
    └── 1º Lote: R$ 300,00 + R$ 15,00 taxa = R$ 315,00 (até 15/Jan)
    └── 2º Lote: R$ 350,00 + R$ 15,00 taxa = R$ 365,00 (até 15/Fev)
    └── Lote Final: R$ 400,00 + R$ 15,00 taxa = R$ 415,00 (até 25/Fev)

  Iniciante
    └── Lote Único: R$ 120,00 + R$ 10,00 taxa = R$ 130,00
```

### 4.2 Fluxo de Checkout

```
  1. Atleta seleciona categoria
  2. Informa parceiro de dupla (busca por nome/email/CPF)
  3. Sistema valida:
     - Política de multi-categoria
     - Vagas disponíveis no lote ativo
     - Parceiro não está em conflito
  4. Cria Order (status=pending) + TeamRegistration (status=pending_payment)
     - idempotencyKey gerado para evitar duplicata
  5. Redireciona para pagamento (gateway)
     - Parcelamento até 12x (configurável)
  6. Webhook do gateway confirma pagamento
     - Order.status → paid
     - TeamRegistration.status → confirmed (ou pending_review)
     - PricingLot.soldCount += 1
     - CheckIn criado com QR code único
  7. Se lote esgota: próximo lote ativa (ou waitlist)
```

### 4.3 Lista de Espera

```
Categoria lotada:
  1. Atleta entra na WaitlistEntry (position auto-incremented)
  2. Quando abre vaga (cancelamento):
     - Primeiro da fila é notificado (email/WhatsApp)
     - WaitlistEntry.status = "notified"
     - WaitlistEntry.expiresAt = now() + 48h
  3. Se confirmar e pagar dentro do prazo:
     - WaitlistEntry.status = "converted"
     - TeamRegistration criada
  4. Se não confirmar:
     - WaitlistEntry.status = "expired"
     - Próximo da fila é notificado
```

### 4.4 Gateway de Pagamento (Abstração)

```typescript
// Interface genérica — implementação por gateway
interface PaymentGateway {
  createCharge(params: {
    amount: number;          // centavos
    currency: string;
    installments: number;
    idempotencyKey: string;
    customerEmail: string;
    description: string;
    metadata: Record<string, string>;
  }): Promise<ChargeResult>;

  processRefund(params: {
    externalId: string;
    amount: number;          // parcial ou total
  }): Promise<RefundResult>;

  parseWebhook(payload: unknown, signature: string): WebhookEvent;
}

// Implementações planejadas:
// - StripeGateway (internacional / NFA)
// - MercadoPagoGateway (Brasil / TAFC / LBF)
// - PixGateway (Brasil, instantâneo)
```

---

## 5. Operação de Evento

### 5.1 Programação Oficial (ScheduleSlot)

Cronograma por dia, visível na página pública:

```
┌──────────────────────────────────────────────────────────┐
│  TAFC #52 — Programação                                  │
│                                                           │
│  📅 Dia 1 — Quarta, 26/Fev                               │
│  ├── 08:00 - 08:30  Abertura e aquecimento               │
│  ├── 08:30 - 12:00  Pré-Qualify (Quadras 1-3)            │
│  ├── 12:00 - 13:00  Intervalo                            │
│  ├── 13:00 - 18:00  Qualify Masculino - Grupos (Q1-Q4)   │
│  └── 18:00 - 20:00  Qualify Feminino - Grupos (Q1-Q2)    │
│                                                           │
│  📅 Dia 2 — Quinta, 27/Fev                               │
│  ├── 08:00 - 12:00  Iniciante (Quadras 1-2)              │
│  ├── 08:00 - 12:00  Intermediário (Quadras 3-4)          │
│  ├── 13:00 - 17:00  Qualify Masc - Mata-mata             │
│  └── 17:00 - 20:00  Qualify Fem - Mata-mata              │
│                                                           │
│  📅 Dia 3 — Sexta, 28/Fev                                │
│  ├── 08:00 - 12:00  Misto B (Quadras 1-3)                │
│  ├── 13:00 - 18:00  Pro Masculino - Grupos               │
│  └── 18:00 - 20:00  Pro Feminino - Grupos                │
│                                                           │
│  📅 Dia 4 — Sábado, 01/Mar                               │
│  ├── 08:00 - 12:00  Pro Masculino - Semis (Best-of-3)    │
│  ├── 13:00 - 15:00  Pro Feminino - Semis (Best-of-3)     │
│  ├── 16:00 - 17:30  Pro Feminino - FINAL (Best-of-3)     │
│  └── 18:00 - 19:30  Pro Masculino - FINAL (Best-of-3)    │
└──────────────────────────────────────────────────────────┘
```

### 5.2 Grade por Quadra (Conflito Prevention)

```
                Quadra 1        Quadra 2        Quadra 3        Quadra 4
08:00-10:00     Pré-Qualify     Pré-Qualify     Pré-Qualify     ─
10:00-12:00     Qual. Masc G1   Qual. Masc G2   Qual. Masc G3   Qual. Masc G4
12:00-13:00     ── INTERVALO ──────────────────────────────────────────────
13:00-15:00     Qual. Fem G1    Qual. Fem G2    Iniciante       Intermediário
15:00-17:00     Qual. Masc QF   Qual. Masc QF   Iniciante       Intermediário
17:00-18:00     Qual. Masc SF   Qual. Fem SF    ─               ─
```

**Validação:** Sistema impede sobreposição de horário na mesma quadra via ScheduleSlot.

### 5.3 Check-In com QR Code

```
Fluxo:
  1. Após pagamento confirmado → CheckIn criado com qrCode único (UUID v4)
  2. Atleta recebe QR code por email/WhatsApp
  3. No dia do evento, staff escaneia QR code
  4. Sistema marca player1CheckedIn / player2CheckedIn separadamente
  5. Quando ambos checked-in → TeamRegistration.status = "checked_in"
  6. Se apenas 1 aparece → status permanece "confirmed" com flag parcial

Detalhes:
  - QR code exibido na tela do app (atleta mostra do celular)
  - Staff usa câmera do celular com leitor do app
  - Offline fallback: busca manual por nome/CPF
```

### 5.4 Controle de Kits

```
CheckIn model inclui:
  - kitDelivered: Boolean
  - kitDeliveredAt: DateTime
  - kitNotes: "Camisa M, Boné, 2x Água, Frutas"

Dashboard do staff mostra:
  ┌─────────────────────────────────────────────────┐
  │  Check-in & Kits — Pro Masculino                │
  │                                                 │
  │  ☑ João + Pedro    ✓ Check-in  ✓ Kit entregue  │
  │  ☑ Carlos + André  ✓ Check-in  ☐ Kit pendente  │
  │  ☐ Lucas + Marcos  ☐ Aguardando check-in       │
  │  ☑ Bruno + Rafael  ✓ Check-in  ✓ Kit entregue  │
  │                                                 │
  │  Progresso: 3/8 duplas com check-in completo    │
  │  Kits entregues: 2/3                            │
  └─────────────────────────────────────────────────┘
```

---

## 6. Página Pública do Evento

### Layout Completo

```
┌──────────────────────────────────────────────────────────────┐
│  ┌────────────────────────────────────────────────────────┐  │
│  │                    HERO / BANNER                       │  │
│  │              TAFC #52 — João Pessoa                    │  │
│  │           26 Fev — 01 Mar 2026                         │  │
│  │          Arena Futevôlei JP, Paraíba                   │  │
│  │                                                        │  │
│  │     [📷 Instagram]  [🌐 Site Oficial]                  │  │
│  └────────────────────────────────────────────────────────┘  │
│                                                              │
│  [Sobre] [Programação] [Categorias] [Inscrições] [Contato]  │
│                                                              │
│  ── Sobre ────────────────────────────────────────────────── │
│  │ A 52ª etapa do circuito TAFC chega a João Pessoa com   │ │
│  │ categorias amadoras e profissionais masculinas e        │ │
│  │ femininas. 4 dias de competição em 4 quadras...        │ │
│  ──────────────────────────────────────────────────────────  │
│                                                              │
│  ── Programação ──────────────────────────────────────────── │
│  │ (ScheduleSlots renderizados por dia, como seção 5.1)   │ │
│  ──────────────────────────────────────────────────────────  │
│                                                              │
│  ── Categorias & Inscrições ──────────────────────────────── │
│  │                                                         │ │
│  │  🏆 Profissional Masculino                              │ │
│  │     Homens · Pro · Bracket · 16 duplas                  │ │
│  │     Best-of-3 em semis/final · Rede 2.20m              │ │
│  │     ┌─────────────────────────────────────────┐         │ │
│  │     │ 2º Lote: R$ 365,00 (até 15/Fev)        │         │ │
│  │     │ Restam 6 vagas                          │         │ │
│  │     │ [Inscrever Dupla]                       │         │ │
│  │     └─────────────────────────────────────────┘         │ │
│  │     Via Qualify ou convite direto                       │ │
│  │                                                         │ │
│  │  🎯 Qualify Masculino                                   │ │
│  │     Homens · Open · Group+Knockout · 32 duplas          │ │
│  │     → Classifica top 8 para Pro Masculino               │ │
│  │     ┌─────────────────────────────────────────┐         │ │
│  │     │ 1º Lote: R$ 215,00 (ATIVO)             │         │ │
│  │     │ Restam 12 vagas                         │         │ │
│  │     │ [Inscrever Dupla]                       │         │ │
│  │     └─────────────────────────────────────────┘         │ │
│  │                                                         │ │
│  │  ⭐ Iniciante                                           │ │
│  │     Misto · Iniciante · Round Robin · 16 duplas         │ │
│  │     ┌─────────────────────────────────────────┐         │ │
│  │     │ ESGOTADO                                │         │ │
│  │     │ [Entrar na Lista de Espera]             │         │ │
│  │     └─────────────────────────────────────────┘         │ │
│  │                                                         │ │
│  ──────────────────────────────────────────────────────────  │
│                                                              │
│  ── Organizador ──────────────────────────────────────────── │
│  │ Organizado por: Team Águia Footvolley Cup               │ │
│  │ 📧 contato@tafc.com.br                                  │ │
│  │ 📱 +55 83 99999-0000 (WhatsApp)                         │ │
│  ──────────────────────────────────────────────────────────  │
│                                                              │
│  ── Política de Reembolso ────────────────────────────────── │
│  │ Cancelamentos até 7 dias antes: reembolso integral.     │ │
│  │ Até 3 dias antes: 50% do valor. Após: não reembolsável.│ │
│  │ Violação de regras: inscrição cancelada sem reembolso.  │ │
│  │ [Ver Regulamento Completo →]                            │ │
│  ──────────────────────────────────────────────────────────  │
│                                                              │
│  ── Compartilhar ─────────────────────────────────────────── │
│  │ [📋 Copiar Link] [📱 WhatsApp] [📘 Facebook]            │ │
│  ──────────────────────────────────────────────────────────  │
└──────────────────────────────────────────────────────────────┘
```

---

## 7. Backoffice / Dashboards

### 7.1 Dashboard do Organizador — Visão Geral

```
┌──────────────────────────────────────────────────────────────┐
│  TAFC #52 — Painel do Organizador                            │
│                                                              │
│  [Visão Geral] [Vendas] [Categorias] [Check-in] [Financeiro]│
│                                                              │
│  ── Resumo ───────────────────────────────────────────────── │
│                                                              │
│  📊 Vendas         💰 Faturamento      👥 Atletas           │
│  87 inscrições     R$ 28.450,00        174 atletas           │
│  +12 esta semana   bruto               únicos                │
│                                                              │
│  ── Ocupação por Categoria ───────────────────────────────── │
│                                                              │
│  Pro Masculino      ████████████████ 16/16  LOTADO           │
│  Pro Feminino       ██████████░░░░░░  7/8   88%             │
│  Qualify Masculino  ████████████████ 28/32  88%             │
│  Qualify Feminino   ████████░░░░░░░░ 10/16  63%             │
│  Iniciante          ████████████████ 16/16  LOTADO           │
│  Intermediário      ██████████████░░ 14/16  88%             │
│  Misto B            ██████░░░░░░░░░░  6/12  50%             │
│                                                              │
│  ── Filas de Espera ──────────────────────────────────────── │
│  Pro Masculino: 4 duplas aguardando                         │
│  Iniciante: 2 duplas aguardando                             │
│                                                              │
│  ── Revisões Pendentes ───────────────────────────────────── │
│  ⚠️ 3 inscrições aguardando validação de nível              │
│  [Ver Todas →]                                              │
└──────────────────────────────────────────────────────────────┘
```

### 7.2 Dashboard de Vendas

```
┌──────────────────────────────────────────────────────────────┐
│  Vendas por Categoria / Lote                                 │
│                                                              │
│  Categoria              Lote           Vendido  Receita      │
│  ─────────────────────────────────────────────────────────── │
│  Pro Masculino          1º Lote        12/12    R$ 3.600     │
│                         2º Lote         4/8     R$ 1.400     │
│  Qualify Masculino      1º Lote        20/20    R$ 3.000     │
│                         2º Lote         8/12    R$ 1.360     │
│  Iniciante              Lote Único     16/16    R$ 1.920     │
│  ...                                                         │
│                                                              │
│  ── Totais ─────────────────────────────────────────────────│
│  Bruto:            R$ 28.450,00                             │
│  Taxas plataforma: R$  1.305,00                             │
│  Taxas gateway:    R$    854,00                             │
│  Líquido:          R$ 26.291,00                             │
│  Chargebacks:      R$      0,00                             │
│  Reembolsos:       R$    650,00 (2 pedidos)                 │
│                                                              │
│  [📥 Exportar CSV] [📥 Exportar XLSX]                       │
└──────────────────────────────────────────────────────────────┘
```

### 7.3 Dashboard de Check-In (Dia do Evento)

```
┌──────────────────────────────────────────────────────────────┐
│  Check-in — Dia 1 (26/Fev)                                  │
│                                                              │
│  Categoria: [Todas ▼]    Buscar: [Nome/CPF...         🔍]  │
│                                                              │
│  ── Qualify Masculino (28 duplas) ────────────────────────── │
│                                                              │
│  ✅ João Silva + Pedro Santos        08:15  Kit ✓           │
│  ✅ Carlos Lima + André Costa        08:22  Kit ✓           │
│  ⚠️ Lucas Rocha + ─                  08:30  Parcial         │
│  ☐  Bruno Alves + Rafael Dias       ─      Aguardando      │
│  ☐  Marcos Oliveira + Thiago Souza  ─      Aguardando      │
│  ...                                                         │
│                                                              │
│  Progresso: 14/28 duplas (50%)                              │
│  Kits entregues: 12/14                                      │
│                                                              │
│  [📷 Escanear QR Code]                                      │
└──────────────────────────────────────────────────────────────┘
```

### 7.4 Relatórios Exportáveis

| Relatório | Campos | Formatos |
|-----------|--------|----------|
| Inscrições | Categoria, Dupla, Atleta1, Atleta2, CPF1, CPF2, Lote, Valor, Status, Data | CSV, XLSX |
| Pagamentos | Order ID, Atleta, Valor, Gateway, Status, Parcelas, Data, Txn ID | CSV, XLSX |
| Check-ins | Categoria, Dupla, Check-in1, Check-in2, Hora, Kit, Staff | CSV, XLSX |
| Financeiro | Categoria, Bruto, Taxas, Líquido, Reembolsos, Chargebacks | CSV, XLSX |
| Atletas | Nome, CPF, Email, Telefone, Nível, Categorias inscritas | CSV, XLSX |

---

## 8. Templates de Evento

### 8.1 TAFC Strict

```json
{
  "templateName": "TAFC Strict",
  "description": "Circuito TAFC — dupla fixa, 1 categoria por atleta, revisão técnica",
  "eventDefaults": {
    "allowMultiCategory": false,
    "numDays": 4,
    "numCourts": 4
  },
  "categories": [
    {
      "name": "Pré-Qualify",
      "gender": "open",
      "skillLevel": "open",
      "format": "group_knockout",
      "maxTeams": 32,
      "isQualifier": true,
      "qualifiesForName": "Qualify Masculino",
      "advanceCount": 8,
      "requiresLevelReview": false
    },
    {
      "name": "Qualify Masculino",
      "gender": "men",
      "skillLevel": "open",
      "format": "group_knockout",
      "maxTeams": 32,
      "isQualifier": true,
      "qualifiesForName": "Profissional Masculino",
      "advanceCount": 8,
      "requiresLevelReview": false
    },
    {
      "name": "Qualify Feminino",
      "gender": "women",
      "skillLevel": "open",
      "format": "group_knockout",
      "maxTeams": 16,
      "isQualifier": true,
      "qualifiesForName": "Profissional Feminino",
      "advanceCount": 4,
      "requiresLevelReview": false
    },
    {
      "name": "Profissional Masculino",
      "gender": "men",
      "skillLevel": "pro",
      "format": "bracket",
      "maxTeams": 16,
      "proLeague": true,
      "netHeight": 2.20,
      "requiresLevelReview": true
    },
    {
      "name": "Profissional Feminino",
      "gender": "women",
      "skillLevel": "pro",
      "format": "bracket",
      "maxTeams": 8,
      "proLeague": true,
      "netHeight": 2.10,
      "requiresLevelReview": true
    },
    {
      "name": "Aprendiz",
      "gender": "open",
      "skillLevel": "beginner",
      "format": "round_robin",
      "maxTeams": 12,
      "requiresLevelReview": false
    },
    {
      "name": "Iniciante",
      "gender": "open",
      "skillLevel": "beginner",
      "format": "group_knockout",
      "maxTeams": 16,
      "requiresLevelReview": false
    },
    {
      "name": "Intermediário",
      "gender": "open",
      "skillLevel": "intermediate",
      "format": "group_knockout",
      "maxTeams": 16,
      "requiresLevelReview": false
    },
    {
      "name": "Misto B",
      "gender": "mixed",
      "skillLevel": "intermediate",
      "format": "group_knockout",
      "maxTeams": 12,
      "requiresLevelReview": false
    },
    {
      "name": "Convidados",
      "gender": "open",
      "skillLevel": "open",
      "format": "round_robin",
      "maxTeams": 8,
      "requiresLevelReview": false
    }
  ]
}
```

### 8.2 LBF Stage

```json
{
  "templateName": "LBF Stage",
  "description": "Etapa do Circuito Brasileiro LBF — múltiplas categorias permitidas",
  "eventDefaults": {
    "allowMultiCategory": true,
    "maxCategoriesPerAthlete": 2,
    "numDays": 3,
    "numCourts": 3
  },
  "categories": [
    {
      "name": "Aprendiz",
      "gender": "open",
      "skillLevel": "beginner",
      "format": "round_robin",
      "maxTeams": 12
    },
    {
      "name": "Iniciante",
      "gender": "open",
      "skillLevel": "beginner",
      "format": "group_knockout",
      "maxTeams": 16
    },
    {
      "name": "Intermediário",
      "gender": "open",
      "skillLevel": "intermediate",
      "format": "group_knockout",
      "maxTeams": 16
    },
    {
      "name": "Misto B",
      "gender": "mixed",
      "skillLevel": "intermediate",
      "format": "group_knockout",
      "maxTeams": 12
    },
    {
      "name": "Qualify",
      "gender": "men",
      "skillLevel": "open",
      "format": "group_knockout",
      "maxTeams": 32,
      "isQualifier": true,
      "qualifiesForName": "Profissional Masculino",
      "advanceCount": 8
    },
    {
      "name": "Profissional Masculino",
      "gender": "men",
      "skillLevel": "pro",
      "format": "bracket",
      "maxTeams": 16,
      "proLeague": true,
      "netHeight": 2.20
    },
    {
      "name": "Profissional Feminino",
      "gender": "women",
      "skillLevel": "pro",
      "format": "bracket",
      "maxTeams": 8,
      "proLeague": true,
      "netHeight": 2.10
    },
    {
      "name": "Convidados",
      "gender": "open",
      "skillLevel": "open",
      "format": "round_robin",
      "maxTeams": 8
    }
  ]
}
```

### 8.3 NFA Open

```json
{
  "templateName": "NFA Open",
  "description": "NFA Footvolley USA — divisões por nível, elegibilidade por divisão",
  "eventDefaults": {
    "allowMultiCategory": false,
    "numDays": 2,
    "numCourts": 4
  },
  "categories": [
    {
      "name": "Open D1",
      "gender": "men",
      "skillLevel": "pro",
      "format": "group_knockout",
      "maxTeams": 16,
      "proLeague": true,
      "netHeight": 2.20,
      "requiresLevelReview": true
    },
    {
      "name": "Open D2",
      "gender": "men",
      "skillLevel": "advanced",
      "format": "group_knockout",
      "maxTeams": 16,
      "netHeight": 2.20,
      "requiresLevelReview": true
    },
    {
      "name": "Open D3",
      "gender": "men",
      "skillLevel": "intermediate",
      "format": "group_knockout",
      "maxTeams": 16,
      "netHeight": 2.20
    },
    {
      "name": "Women",
      "gender": "women",
      "skillLevel": "open",
      "format": "group_knockout",
      "maxTeams": 8,
      "netHeight": 2.10
    },
    {
      "name": "Master 45+",
      "gender": "men",
      "skillLevel": "open",
      "ageGroup": "master45",
      "format": "group_knockout",
      "maxTeams": 8,
      "netHeight": 2.20
    },
    {
      "name": "Beginners",
      "gender": "open",
      "skillLevel": "beginner",
      "format": "round_robin",
      "maxTeams": 12,
      "netHeight": 2.20
    }
  ]
}
```

### 8.4 Evento Simples (backward-compatible)

```json
{
  "templateName": "Evento Simples",
  "description": "Torneio único — formato clássico sem sub-categorias",
  "eventDefaults": {
    "allowMultiCategory": false,
    "numDays": 1,
    "numCourts": 2
  },
  "categories": [
    {
      "name": "Principal",
      "gender": "open",
      "skillLevel": "open",
      "format": "bracket",
      "maxTeams": 16
    }
  ]
}
```

### 8.5 King of the Beach

```json
{
  "templateName": "King of the Beach",
  "description": "Formato individual KOTB — parceiros rotativos",
  "eventDefaults": {
    "allowMultiCategory": false,
    "numDays": 1,
    "numCourts": 2
  },
  "categories": [
    {
      "name": "King of the Beach",
      "gender": "men",
      "skillLevel": "open",
      "format": "king_of_the_beach",
      "maxTeams": 16
    }
  ]
}
```

---

## 9. Fluxos UX Detalhados

### 9.1 Criação de Evento (Organizador)

```
Step 1: Informações do Evento
  ┌────────────────────────────────────────────────────┐
  │ Nome do Evento: [TAFC #52 - João Pessoa          ]│
  │ Descrição: [52ª etapa do circuito TAFC...        ]│
  │ Local: [Arena Futevôlei JP                       ]│
  │ Cidade: [João Pessoa] Estado: [PB] País: [Brasil]│
  │ Início: [26/02/2026]  Fim: [01/03/2026]          │
  │ Quadras: [4]  Dias: [4]  Horas/dia: [12]         │
  │ Instagram: [@tafc_oficial]  Site: [tafc.com.br]   │
  │                                                    │
  │              [Próximo: Categorias →]                │
  └────────────────────────────────────────────────────┘

Step 2: Template & Categorias
  ┌────────────────────────────────────────────────────┐
  │ Começar com um template:                           │
  │                                                    │
  │ [🏆 TAFC Strict]  [🏐 LBF Stage]  [🇺🇸 NFA Open] │
  │ [📋 Simples]      [👑 KOTB]       [Vazio]         │
  │                                                    │
  │ ── Políticas do Evento ─────────────────────────── │
  │                                                    │
  │ Múltiplas categorias por atleta:                   │
  │  (●) Não — 1 categoria por atleta (TAFC Strict)   │
  │  ( ) Sim — permitir múltiplas                      │
  │       Máximo por atleta: [2]                       │
  │                                                    │
  │ Política de reembolso:                             │
  │  [Até 7 dias: integral. Até 3 dias: 50%...      ] │
  │                                                    │
  │ Email suporte: [contato@tafc.com.br]               │
  │ WhatsApp: [+55 83 99999-0000]                      │
  │                                                    │
  │ ── Categorias ──────────────────────────────────── │
  │                                                    │
  │ [+ Adicionar]  (categorias do template aparecem)   │
  │                                                    │
  │ ┌─────────────────────────────────────────────┐    │
  │ │ 🏆 Profissional Masculino                   │    │
  │ │   Homens · Pro · Bracket · 16 duplas        │    │
  │ │   Bo3 semis/final · Rede 2.20m              │    │
  │ │   ✅ Revisão técnica obrigatória             │    │
  │ │   [Editar] [Duplicar] [Lotes] [Remover]     │    │
  │ └─────────────────────────────────────────────┘    │
  │ ┌─────────────────────────────────────────────┐    │
  │ │ 🎯 Qualify Masculino                        │    │
  │ │   Homens · Open · G+KO · 32 duplas          │    │
  │ │   → Classifica 8 para Pro Masculino          │    │
  │ │   [Editar] [Duplicar] [Lotes] [Remover]     │    │
  │ └─────────────────────────────────────────────┘    │
  │ ┌─────────────────────────────────────────────┐    │
  │ │ ⭐ Iniciante                                 │    │
  │ │   Misto · Iniciante · Round Robin · 16       │    │
  │ │   [Editar] [Duplicar] [Lotes] [Remover]     │    │
  │ └─────────────────────────────────────────────┘    │
  │ ...                                                │
  │                                                    │
  │     [← Voltar]     [Próximo: Lotes & Preços →]    │
  └────────────────────────────────────────────────────┘

Step 3: Lotes & Preços (por categoria)
  ┌────────────────────────────────────────────────────┐
  │ Configurar lotes de venda por categoria:           │
  │                                                    │
  │ ── Profissional Masculino ─────────────────────── │
  │ ┌─────────────────────────────────────────────┐    │
  │ │ 1º Lote: R$ 300,00  Taxa: R$ 15,00         │    │
  │ │ Vagas: 12  De: 01/Jan  Até: 15/Jan         │    │
  │ │ [Editar] [Remover]                          │    │
  │ └─────────────────────────────────────────────┘    │
  │ ┌─────────────────────────────────────────────┐    │
  │ │ 2º Lote: R$ 350,00  Taxa: R$ 15,00         │    │
  │ │ Vagas: 8   De: 16/Jan  Até: 15/Fev         │    │
  │ └─────────────────────────────────────────────┘    │
  │ [+ Adicionar Lote]                                 │
  │                                                    │
  │ ── Qualify Masculino ──────────────────────────── │
  │ ┌─────────────────────────────────────────────┐    │
  │ │ Lote Único: R$ 200,00  Taxa: R$ 10,00      │    │
  │ │ Vagas: 32  De: 01/Jan  Até: 20/Fev         │    │
  │ └─────────────────────────────────────────────┘    │
  │ ...                                                │
  │                                                    │
  │     [← Voltar]     [Próximo: Programação →]        │
  └────────────────────────────────────────────────────┘

Step 4: Programação (opcional — pode fazer depois)
  ┌────────────────────────────────────────────────────┐
  │ Montar cronograma por dia:                         │
  │                                                    │
  │ Dia 1 (26/Fev):                                    │
  │ [+ Adicionar Slot]                                 │
  │ ┌─────────────────────────────────────────────┐    │
  │ │ 08:00-08:30  Abertura (todas quadras)       │    │
  │ │ Tipo: ceremony                              │    │
  │ │ [Editar] [Remover]                          │    │
  │ └─────────────────────────────────────────────┘    │
  │ ┌─────────────────────────────────────────────┐    │
  │ │ 08:30-12:00  Pré-Qualify (Quadras 1-3)      │    │
  │ │ Tipo: competition  Categoria: Pré-Qualify   │    │
  │ │ [Editar] [Remover]                          │    │
  │ └─────────────────────────────────────────────┘    │
  │ ...                                                │
  │                                                    │
  │     [← Voltar]     [Criar Evento ✓]                │
  └────────────────────────────────────────────────────┘
```

### 9.2 Inscrição do Atleta

```
  1. Atleta acessa página pública do evento
  2. Clica "Inscrever Dupla" na categoria desejada
  3. Se não logado → redireciona para login/registro
  4. Formulário de inscrição:
     ┌────────────────────────────────────────────────┐
     │ Inscrição — Qualify Masculino                   │
     │ TAFC #52 - João Pessoa                          │
     │                                                 │
     │ Atleta 1: João Silva (você)                     │
     │                                                 │
     │ Atleta 2 (parceiro):                            │
     │ [Buscar por nome, email ou CPF... 🔍]           │
     │                                                 │
     │   → Pedro Santos (pedro@email.com)     [✓]     │
     │   → Pedro Oliveira (pedro.o@email.com) [ ]     │
     │                                                 │
     │ Nome da dupla (opcional): [Silva & Santos    ]  │
     │                                                 │
     │ ── Valor ───────────────────────────────────── │
     │ 1º Lote: R$ 200,00                             │
     │ Taxa: R$ 10,00                                  │
     │ Total: R$ 210,00                                │
     │ Parcelamento: [1x R$ 210,00 ▼]                 │
     │                                                 │
     │ ☑ Li e aceito a política de reembolso           │
     │ ☑ Confirmo que ambos atletas estão cientes      │
     │                                                 │
     │ [Prosseguir para Pagamento →]                   │
     └────────────────────────────────────────────────┘

  5. Validações antes do checkout:
     - Política de multi-categoria (por userId + CPF)
     - Vagas disponíveis no lote ativo
     - Parceiro não está em conflito com regras
     - Nível técnico (se requiresLevelReview, inscrição fica pending_review)

  6. Pagamento via gateway → webhook confirma
  7. QR code gerado e enviado por email
  8. Se requiresLevelReview: aguarda aprovação do organizador
```

### 9.3 Visualização do Evento (Espectador/Atleta)

```
┌──────────────────────────────────────────────────────┐
│ TAFC #52 — João Pessoa                               │
│                                                       │
│ [Sobre] [Programação] [Categorias] [Resultados]     │
│                                                       │
│ Tab "Resultados":                                    │
│                                                       │
│ Categoria: [Pro Masculino ▼]                         │
│                                                       │
│ [Jogos] [Classificação] [Chave] [Duplas]             │
│                                                       │
│ ... bracket/games/standings da categoria selecionada │
│                                                       │
│ ── Overview (todas categorias) ─────────────────────│
│                                                       │
│ Pro Masculino:     ████████░░  Semifinais            │
│ Pro Feminino:      ██████████  CONCLUÍDO ✓           │
│ Qualify Masculino: ██████████  CONCLUÍDO ✓           │
│ Iniciante:         ██████░░░░  Fase de Grupos        │
│ Intermediário:     ████░░░░░░  Fase de Grupos        │
└──────────────────────────────────────────────────────┘
```

---

## 10. Migração e Backward Compatibility

### Estratégia

```
Torneios existentes (sem categorias):

  1. Para cada Tournament existente:
     → Criar Category "Principal" com:
        - name = "Principal"
        - format = Tournament.format
        - maxTeams = Tournament.maxPlayers
        - pointsPerSet = Tournament.pointsPerSet
        - numSets = Tournament.numSets
        - groupSize = Tournament.groupSize
        - proLeague = Tournament.proLeague
        - avgGameMinutes = Tournament.avgGameMinutes
        - gender = "open"
        - skillLevel = "open"

  2. Para cada Game existente:
     → Setar categoryId = id da Category "Principal"

  3. Para cada Group existente:
     → Setar categoryId = id da Category "Principal"

  4. Para cada Round existente:
     → Setar categoryId = id da Category "Principal"

  5. Para cada TournamentPlayer existente:
     → Setar categoryId = id da Category "Principal"

  6. Tournament mantém campos legados (nullable) para queries antigos

  7. UI detecta:
     - 1 categoria → mostra simplificado (sem seletor)
     - N categorias → mostra seletor completo
```

### Migration Script (Prisma)

```sql
-- 1. Adicionar novas tabelas e colunas
-- 2. Para cada tournament, criar category "Principal"
-- 3. UPDATE Game SET categoryId = (SELECT id FROM Category WHERE tournamentId = Game.tournamentId AND name = 'Principal')
-- 4. Repetir para Group, Round, TournamentPlayer
-- 5. Tornar campos do Tournament nullable (format, maxPlayers, etc.)
```

---

## 11. Segurança e Requisitos Não-Funcionais

### 11.1 Responsividade
- 100% web responsivo (mobile-first)
- Página pública do evento otimizada para compartilhamento WhatsApp
- QR code scanner funciona via câmera do celular
- Dashboard do organizador usável em tablet

### 11.2 Pagamento
- Gateway certificado PCI DSS (Stripe / MercadoPago)
- Nunca armazenar dados de cartão no nosso banco
- Idempotência obrigatória em todas operações de pagamento
- Webhook com verificação de assinatura
- Retry automático com backoff exponencial

### 11.3 Auditoria
- Toda ação administrativa gera AuditLog
- Log inclui: who, what, when, before/after, IP
- Ações logadas: alteração de categoria, aprovação/rejeição técnica, reembolso, mudança de política, promoção de classify
- Retenção: mínimo 2 anos

### 11.4 Idempotência
- Pagamentos: via idempotencyKey no Order
- Webhooks: deduplicação por externalId na PaymentTransaction
- Inscrições: unique constraint [categoryId, player1Id, player2Id]

### 11.5 Performance
- Página pública: SSR com cache (revalidate 60s)
- Dashboard: client-side com SWR/React Query
- Exportações: geração assíncrona para relatórios grandes
- Índices otimizados em todas FKs e campos de filtro

---

## 12. Fases de Implementação

### Fase 1 — Fundação: Schema + Category CRUD (Semana 1-2)
1. ✏️ Criar models: Category, ScheduleSlot, AuditLog
2. ✏️ Adicionar categoryId em Game, Group, Round, TournamentPlayer
3. ✏️ Adicionar campos de política no Tournament
4. ✏️ Migration script para dados existentes
5. ✏️ API CRUD para Category (`/api/tournaments/[id]/categories`)
6. ✏️ API para templates (`/api/templates`)
7. 🧪 Testar backward compatibility com torneios existentes

### Fase 2 — UI de Criação Multi-Step (Semana 2-3)
1. 🎨 Refatorar `/tournaments/create` em wizard multi-step
2. 🎨 Step 1: Info do evento
3. 🎨 Step 2: Template selector + painel de categorias + modal de edição
4. 🎨 Step 3: Lotes & preços por categoria
5. 🎨 Step 4: Programação (ScheduleSlots)
6. 🎨 Políticas do evento (multi-categoria, reembolso, contato)

### Fase 3 — Geração & Visualização por Categoria (Semana 3-4)
1. ⚙️ Adaptar scheduling.ts para operar por categoryId
2. ⚙️ Adaptar `/api/tournaments/[id]/generate` para gerar por categoria
3. 🎨 Seletor de categoria na página do torneio
4. 🎨 Overview multi-categoria com barras de progresso
5. 🎨 Bracket/Group/RoundRobin views filtrados por categoria
6. 🎨 Standings por categoria

### Fase 4 — Comercial: Inscrição + Pagamento (Semana 4-6)
1. ✏️ Criar models: TeamRegistration, PricingLot, Order, PaymentTransaction, WaitlistEntry
2. ⚙️ API de inscrição por dupla com validações
3. ⚙️ Validação de política multi-categoria (userId + CPF)
4. ⚙️ Lógica de lotes (ativação, esgotamento, próximo lote)
5. ⚙️ Integração com gateway de pagamento (Stripe primeiro)
6. ⚙️ Webhook handler com idempotência
7. 🎨 Página pública do evento com CTA de inscrição
8. 🎨 Fluxo de checkout
9. ⚙️ Lista de espera (waitlist)

### Fase 5 — Operação: Check-in + Kits (Semana 6-7)
1. ✏️ Criar model: CheckIn
2. ⚙️ Geração de QR code (UUID + encoding)
3. ⚙️ API de check-in (scan QR → marca presença)
4. 🎨 Tela de scanner QR (staff)
5. 🎨 Dashboard de check-in com filtros
6. 🎨 Controle de kits

### Fase 6 — Validação Técnica + Qualify Chain (Semana 7-8)
1. ⚙️ Workflow de revisão (pending_review → approved/reallocated/rejected)
2. 🎨 Dashboard de revisões pendentes para organizador
3. ⚙️ Promoção automática Qualify → Principal
4. ⚙️ AuditLog para todas ações de revisão

### Fase 7 — Backoffice + Relatórios (Semana 8-9)
1. 🎨 Dashboard do organizador (vendas, ocupação, filas)
2. 🎨 Dashboard financeiro (bruto, taxas, líquido, reembolsos)
3. ⚙️ Exportação CSV/XLSX (inscrições, pagamentos, check-ins)
4. 🎨 Página pública completa (hero, programação, compartilhamento)

### Fase 8 — Polish + MercadoPago (Semana 9-10)
1. ⚙️ Gateway MercadoPago (Brasil)
2. ⚙️ PIX como método de pagamento
3. 🎨 Notificações por email (confirmação, QR code, waitlist)
4. 🧪 E2E testing de todos os fluxos
5. 📱 Otimização mobile + share WhatsApp

---

## Legenda

- ✏️ = Schema/Database
- ⚙️ = Backend/API
- 🎨 = Frontend/UI
- 🧪 = Testing
- 📱 = Mobile/responsive
