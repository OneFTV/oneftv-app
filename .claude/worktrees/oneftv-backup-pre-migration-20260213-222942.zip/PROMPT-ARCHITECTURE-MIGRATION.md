# Prompt para Claude CLI — Migração Arquitetural OneFTV

Copie o prompt abaixo e cole no Claude CLI.

---

## PROMPT

```
Você vai reestruturar a aplicação OneFTV de uma arquitetura flat para modular monolith. Esta é uma migração incremental — a app deve funcionar em cada passo intermediário.

## CONTEXTO

Leia estes 2 documentos ANTES de fazer qualquer coisa:
- ARCHITECTURE-REVIEW.md (diagnóstico completo + estrutura proposta)
- PROPOSAL-MULTI-CATEGORY.md (sistema multi-categoria que será implementado DEPOIS)

A app é um Next.js 14 footvolley tournament manager com Prisma + MySQL.

## PASSO 0 — BACKUP

ANTES DE QUALQUER MUDANÇA, crie um backup:

```bash
cd /Users/mac-mini/oneftv-app/.claude/worktrees/adoring-williamson
zip -r ../oneftv-backup-pre-migration-$(date +%Y%m%d-%H%M%S).zip . -x "node_modules/*" -x ".next/*" -x ".git/*" -x "package-lock.json"
```

Confirme que o zip foi criado com sucesso antes de prosseguir.

## PASSO 1 — CRIAR SHARED LAYER

Criar os arquivos fundacionais que todos os módulos vão usar.

### 1.1 shared/database/prisma.ts
Mover de src/lib/db.ts. Manter o mesmo singleton pattern. NÃO deletar lib/db.ts ainda — criar um re-export temporário para não quebrar imports existentes.

### 1.2 shared/database/transaction.ts
Criar helper withTransaction() que wrapa prisma.$transaction com maxWait: 5000 e timeout: 10000.

### 1.3 shared/api/errors.ts
Criar classes de erro:
- AppError (base: code, message, statusCode, details?)
- NotFoundError (404)
- ForbiddenError (403)
- ValidationError (400, com details do Zod)
- ConflictError (409)
- UnauthorizedError (401)
- PolicyViolationError (422)

### 1.4 shared/api/response.ts
Criar helpers:
- apiSuccess<T>(data: T, status?: number) → NextResponse com { success: true, data }
- apiPaginated<T>(data: T[], meta: { page, limit, total, pages }) → NextResponse com { success: true, data, meta }
- apiError(error: unknown) → NextResponse que detecta AppError vs erro genérico

### 1.5 shared/api/pagination.ts
Criar parsePagination(searchParams: URLSearchParams) que retorna { page, limit, skip } com defaults e validação (page >= 1, limit entre 1-50).

### 1.6 shared/middleware/with-auth.ts
Extrair o padrão de auth check que se repete 12 vezes nas API routes:
```typescript
const session = await getServerSession(authOptions);
if (!session || !session.user?.id) { return 401; }
```
Criar função withAuth(handler) que recebe um handler tipado e retorna route handler com sessão já validada.

### 1.7 shared/middleware/with-validation.ts
Criar withValidation(zodSchema, handler) que parseia req.json(), valida com Zod, e chama handler com dados validados. Se falha, retorna ValidationError.

### 1.8 shared/config/constants.ts
Centralizar magic numbers que estão espalhados pelo código:
- DEFAULT_POINTS_PER_SET = 18
- DEFAULT_DECIDING_SET_POINTS = 15
- DEFAULT_GROUP_SIZE = 4
- DEFAULT_MAX_PLAYERS = 16
- DEFAULT_COURTS = 2
- DEFAULT_GAME_DURATION_MINUTES = 20
- DEFAULT_HOURS_PER_DAY = 8
- NET_HEIGHT_MEN = 2.20
- NET_HEIGHT_WOMEN = 2.10

### 1.9 shared/audit/audit.service.ts
Criar AuditService com método log({ action, entityType, entityId, userId?, details?, ipAddress? }) que cria registro no AuditLog (quando o model existir no Prisma — por enquanto, console.log como placeholder).

### 1.10 Atualizar tsconfig.json
Adicionar path aliases:
```json
"paths": {
  "@/*": ["./src/*"],
  "@/modules/*": ["./src/modules/*"],
  "@/shared/*": ["./src/shared/*"],
  "@/hooks/*": ["./src/hooks/*"]
}
```

## PASSO 2 — MÓDULO TOURNAMENT

Extrair business logic de torneios para módulo isolado.

### 2.1 modules/tournament/tournament.constants.ts
Single source of truth para status e format:
```typescript
export const TOURNAMENT_STATUS = {
  DRAFT: 'draft',
  REGISTRATION: 'registration',
  IN_PROGRESS: 'in_progress',
  COMPLETED: 'completed',
  CANCELLED: 'cancelled',
} as const;

export const TOURNAMENT_FORMAT = {
  KING_OF_THE_BEACH: 'king_of_the_beach',
  BRACKET: 'bracket',
  GROUP_KNOCKOUT: 'group_knockout',
  ROUND_ROBIN: 'round_robin',
} as const;
```

### 2.2 modules/tournament/tournament.types.ts
Types derivados do Prisma, não mais enums soltos. Import type from '@prisma/client'.

### 2.3 modules/tournament/tournament.schemas.ts
Extrair/criar Zod schemas para create e update de torneio.

### 2.4 modules/tournament/tournament.repository.ts
Classe com métodos: findById, findMany (com filtros e paginação), create, update, updateStatus, delete. Toda query Prisma de torneio fica AQUI e em nenhum outro lugar.

### 2.5 modules/tournament/tournament.service.ts
Business logic: create, getById, list, update, updateStatus, delete. Usa repository internamente. Valida transições de status. Verifica ownership do organizer.

### 2.6 Refatorar API routes de torneio
- src/app/api/tournaments/route.ts → usar TournamentService (GET list + POST create)
- src/app/api/tournaments/[id]/route.ts → usar TournamentService (GET detail + PUT update + DELETE)
As routes devem ficar com ~25-30 linhas cada. Usar withAuth e withValidation onde aplicável.

## PASSO 3 — MÓDULO GAME

### 3.1 modules/game/game.types.ts
### 3.2 modules/game/game.schemas.ts
### 3.3 modules/game/score.validator.ts
Extrair TODA a lógica de validação de score de api/games/[id]/route.ts:
- Regra de win-by-2
- Best-of-3 set logic
- Deciding set to 15 points
- Determinação de winningSide

### 3.4 modules/game/game.repository.ts
### 3.5 modules/game/game.service.ts
### 3.6 Refatorar api/games/[id]/route.ts para ~25 linhas

## PASSO 4 — MÓDULO SCHEDULING

### 4.1 modules/scheduling/scheduling.types.ts
### 4.2 modules/scheduling/generators/bracket.generator.ts
Extrair generateBracketGames() de lib/scheduling.ts

### 4.3 modules/scheduling/generators/group.generator.ts
Extrair generateKotBGroups() e generateGroupKnockoutGames() de lib/scheduling.ts

### 4.4 modules/scheduling/generators/kotb.generator.ts
Extrair TUDO de lib/kotb.ts (generateKotBRoundRobin, calculateKotBStandings, getKotBAdvancingPlayers, generateKotBKnockout)

### 4.5 modules/scheduling/generators/round-robin.generator.ts
Extrair generateRoundRobinGames() de lib/scheduling.ts

### 4.6 modules/scheduling/scheduling.service.ts
Orquestrador que chama o generator correto baseado no format. ADICIONAR withTransaction() para toda a geração.

### 4.7 modules/scheduling/bracket-utils.ts
Mover de lib/bracketUtils.ts

### 4.8 Refatorar api/tournaments/[id]/generate/route.ts para ~20 linhas
### 4.9 Refatorar api/tournaments/[id]/games/route.ts para ~20 linhas
### 4.10 Refatorar api/tournaments/[id]/players/route.ts para ~20 linhas

## PASSO 5 — MÓDULOS ATHLETE, RANKING, AUTH

### 5.1 modules/athlete/
- athlete.service.ts, athlete.repository.ts, athlete.types.ts
- Refatorar api/athletes/ routes

### 5.2 modules/ranking/
- ranking.service.ts, ranking.types.ts
- Refatorar api/rankings/route.ts

### 5.3 modules/auth/
- Mover lib/auth.ts → modules/auth/auth.config.ts
- Criar modules/auth/auth.service.ts (register, getCurrentUser)
- Refatorar api/auth/ routes
- Criar re-export em lib/auth.ts para não quebrar NextAuth imports existentes

## PASSO 6 — HOOKS E RE-EXPORTS

### 6.1 hooks/use-fetch.ts
Criar hook genérico de data fetching (pode usar fetch nativo com pattern de loading/error/data — SWR é opcional, não precisa instalar agora).

### 6.2 hooks/use-pagination.ts

### 6.3 Atualizar lib/ com re-exports
Para manter backward compatibility, lib/ deve re-exportar dos novos módulos:
```typescript
// lib/db.ts → re-export de shared/database/prisma.ts
// lib/auth.ts → re-export de modules/auth/auth.config.ts
// lib/scheduling.ts → re-export de modules/scheduling/
// lib/kotb.ts → re-export de modules/scheduling/generators/kotb.generator.ts
// lib/bracketUtils.ts → re-export de modules/scheduling/bracket-utils.ts
```

## PASSO 7 — LIMPEZA

### 7.1 Deletar código morto
- Deletar src/app/api/live-feed/ (duplicado — manter apenas /api/livefeed)
- Deletar src/app/live-feed/ (page duplicada)
- Deletar src/lib/liveFeedStore.ts (storage JSON não usado)

### 7.2 Limpar types/index.ts
- Remover enums que ninguém importa (TournamentFormat, TournamentStatus, GameStatus, UserRole, PlayerLevel)
- Manter interfaces que ainda são usadas por componentes (mover gradualmente)
- Adicionar comentário: "// LEGACY: these types are being migrated to modules/*/types.ts"

### 7.3 Mover @types/* para devDependencies
@types/bcryptjs e @types/uuid devem estar em devDependencies, não dependencies.

## REGRAS OBRIGATÓRIAS

1. **NUNCA deletar um arquivo sem antes criar o substituto e atualizar todos os imports**
2. **Após CADA passo, rodar `npx tsc --noEmit` e confirmar ZERO erros**
3. **Após CADA passo, rodar `npm run build` e confirmar que compila**
4. **Se algum passo falhar, corrigir ANTES de prosseguir**
5. **NÃO instalar dependências novas — usar apenas o que já existe no package.json**
6. **NÃO alterar o schema.prisma neste momento — isso será feito na implementação da multi-categoria**
7. **NÃO alterar components/ ou pages/ neste momento — apenas API routes e lib/**
8. **NÃO alterar o seed.ts**
9. **Manter lib/*.ts como re-exports para backward compat até que todos os imports sejam atualizados**

## VALIDAÇÃO FINAL

Após completar todos os passos:

1. `npx tsc --noEmit` → ZERO errors
2. `npm run build` → Build successful
3. Verificar que a estrutura de pastas está correta:
   - src/shared/ existe com database/, api/, middleware/, config/, audit/
   - src/modules/ existe com tournament/, game/, scheduling/, athlete/, ranking/, auth/
   - src/hooks/ existe com use-fetch.ts
   - src/lib/ existe com re-exports (backward compat)
4. Contar linhas das API routes refatoradas — nenhuma deve ter mais de 40 linhas
5. Nenhum API route deve importar prisma diretamente — deve usar repository via service
```

---

## COMO USAR

```bash
# 1. Navegue até o diretório do projeto
cd /Users/mac-mini/oneftv-app/.claude/worktrees/adoring-williamson

# 2. Copie o prompt acima (da seção ## PROMPT até o final)

# 3. Execute no Claude CLI
claude

# 4. Cole o prompt

# 5. Acompanhe a execução — o agent vai pedir permissão para cada comando bash
```
