# Avaliação Arquitetural Consolidada — OneFTV

**Versão:** 3.0 — Consolidação Claude Code + Codex
**Data:** 2026-02-13
**Contexto:** Preparar app para sistema multi-categoria (TAFC/LBF/NFA), milhares de usuários, trabalho paralelo multi-dev/AI, baixo custo.

---

## Índice

1. [Diagnóstico: O que já está bom](#1-diagnóstico-o-que-já-está-bom)
2. [Problemas Confirmados com Evidências](#2-problemas-confirmados-com-evidências)
3. [Estrutura Modular Proposta](#3-estrutura-modular-proposta)
4. [Padrões e Convenções](#4-padrões-e-convenções)
5. [Escalabilidade e Performance](#5-escalabilidade-e-performance)
6. [Trabalho Paralelo Multi-Dev/AI](#6-trabalho-paralelo-multi-devai)
7. [Infraestrutura de Baixo Custo](#7-infraestrutura-de-baixo-custo)
8. [Plano de Migração Incremental](#8-plano-de-migração-incremental)

---

## 1. Diagnóstico: O que já está bom

| # | Ponto forte | Evidência |
|---|-------------|-----------|
| ✅ | Stack moderna e viável | Next 14 + Prisma + MySQL + TypeScript strict — `package.json`, `tsconfig.json` |
| ✅ | Índices no banco | `@@index` em todas FKs — `schema.prisma` lines 68-70, 92-93, etc |
| ✅ | Validação Zod em rotas críticas | 9/18 rotas usam Zod — `games/[id]/route.ts`, `tournaments/route.ts` |
| ✅ | Prisma singleton | Evita connection leak em dev/hot reload — `lib/db.ts` |
| ✅ | Padrão consistente de pages | 90% das 16 páginas seguem mesmo pattern |
| ✅ | Auth check uniforme | NextAuth + session check em 12/18 rotas protegidas |
| ✅ | Professional League system | Best-of-3 scoring bem implementado com validação de sets |
| ✅ | Path aliases | `@/*` configurado — clean imports sem relative paths |

**Veredito: MVP funcional e sólido, mas NÃO pronto para escala organizacional e operacional.**

---

## 2. Problemas Confirmados com Evidências

### 🔴 CRÍTICOS — Bloqueiam escalabilidade

---

#### C1. Sem camada de serviço — Business logic inline em routes

**O que acontece:**
```
API Route (237 linhas) = HTTP handling + autenticação + validação
                       + queries Prisma + regras de negócio + response
```

**Evidência:** Todas as 18 API routes chamam `prisma.*` diretamente.

```typescript
// api/tournaments/[id]/route.ts — 237 linhas, TUDO inline
const tournament = await prisma.tournament.findUnique({
  where: { id: params.id },
  include: {
    organizer: { select: { id: true, name: true, email: true } },
    players: { include: { user: { select: { id: true, name: true, email: true } } } },
    groups: { include: { players: true } },
    games: { include: { player1Home: ..., player2Home: ..., player1Away: ..., player2Away: ... } },
    rounds: { include: { games: true } },
  },
});
```

**Impacto:**
- Impossível reutilizar lógica entre rotas
- Impossível testar business logic sem HTTP
- Cada dev/agent que toca num route pode quebrar tudo

---

#### C2. Zero transações no banco — Dados podem corromper

**Evidência 1: `api/tournaments/[id]/generate/route.ts` lines 65-124**
```typescript
// 3 deletes separados (se falhar entre eles = dados parciais)
await prisma.game.deleteMany({ where: { tournamentId: params.id } });    // OK
await prisma.round.deleteMany({ where: { tournamentId: params.id } });   // ← falha aqui?
await prisma.group.deleteMany({ where: { tournamentId: params.id } });   // ← nunca executa

// N creates em loops aninhados (sem rollback)
for (let i = 0; i < groups.length; i++) {
  const group = await prisma.group.create({ ... });       // Cria grupo 1 OK
  for (const userId of groups[i]) {
    await prisma.tournamentPlayer.updateMany({ ... });     // ← falha no meio?
  }
  const round = await prisma.round.create({ ... });        // ← nunca executa
  for (const game of groupGames) {
    await prisma.game.create({ ... });                     // ← jogos parciais
  }
}

// Status atualizado separado do resto
await prisma.tournament.update({ data: { status: "in_progress" } }); // ← pode marcar "em andamento" sem jogos
```

**Cenário de falha real:** Se a geração falhar na 3ª rodada de 5, o torneio fica com 2 grupos criados, 0 jogos na 3ª rodada, mas status "in_progress". Dados inconsistentes sem rollback.

**Evidência 2: `api/tournaments/[id]/register/route.ts` lines 46-80**
```typescript
// CHECK: conta jogadores em memória
if (tournament.players.length >= tournament.maxPlayers) { return 400; }

// CHECK: verifica se já registrado em memória
const alreadyRegistered = tournament.players.some(p => p.userId === session.user.id);

// CREATE: cria registro (separado dos checks!)
const tournamentPlayer = await prisma.tournamentPlayer.create({ ... });
```

**Race condition:** Dois jogadores fazem check ao mesmo tempo, ambos veem 15/16, ambos criam → 17/16. Sem transação + lock.

---

#### C3. Componentes-página monolíticos (400-600 linhas)

**Evidência — maiores arquivos:**

| Arquivo | Linhas | Conteúdo misturado |
|---------|--------|---------------------|
| `tournaments/[id]/manage/page.tsx` | 599 | Score entry + status management + game list + validação |
| `tournaments/[id]/page.tsx` | 595 | 4 tabs (overview + bracket + players + standings) |
| `profile/page.tsx` | 576 | Profile + edit form + stats + tournament history |
| `tournaments/create/page.tsx` | 519 | Form completo + validação + submit + todos os campos |
| `tournaments/[id]/games/page.tsx` | 424 | Game list + filters + score display |
| `dashboard/page.tsx` | 389 | Stats + tournaments + games + quick actions |

**Impacto:** 2 devs/agents trabalhando em `manage/page.tsx` = merge conflict 100% garantido.

---

#### C4. Zero testes automatizados

**Evidência:**
```bash
find src/ -name "*.test.*" -o -name "*.spec.*"    # → 0 resultados
find . -name "jest.config*" -o -name "vitest*"     # → 0 resultados
grep -r '"test"' package.json                       # → não existe script "test"
```

**Impacto:** Qualquer refatoração ou feature nova pode quebrar silenciosamente. Agents IA não têm como validar mudanças.

---

#### C5. Tipos desconectados do runtime — 3 sistemas paralelos

**Evidência concreta:**

```
CAMADA 1: TypeScript Enums (src/types/index.ts) — NUNCA USADOS
  TournamentStatus.DRAFT = 'DRAFT'
  TournamentStatus.REGISTRATION_OPEN = 'REGISTRATION_OPEN'
  TournamentStatus.REGISTRATION_CLOSED = 'REGISTRATION_CLOSED'
  TournamentStatus.IN_PROGRESS = 'IN_PROGRESS'
  TournamentStatus.PAUSED = 'PAUSED'
  TournamentStatus.COMPLETED = 'COMPLETED'
  TournamentStatus.CANCELLED = 'CANCELLED'
  → 7 estados, UPPER_CASE

CAMADA 2: Banco de dados + API routes — VALORES REAIS
  schema.prisma default: "draft"
  api/tournaments/route.ts: "registration"
  api/tournaments/[id]/register/route.ts: "registration"
  api/tournaments/[id]/generate/route.ts: "in_progress"
  → 4 estados, lowercase_snake_case

CAMADA 3: Frontend dashboard (dashboard/page.tsx line 15)
  status: 'upcoming' | 'ongoing' | 'completed'
  → 3 estados, nomes DIFERENTES

Grep por 'TournamentStatus.' em todo src/ → 0 resultados
Grep por 'TournamentFormat.' em todo src/ → 0 resultados
Os enums existem mas NINGUÉM os importa.
```

**Impacto:** Bugs silenciosos. Um dev compara `status === TournamentStatus.IN_PROGRESS` (que é `'IN_PROGRESS'`) mas o banco retorna `'in_progress'`. Sempre falso.

---

### 🟡 IMPORTANTES — Prejudicam manutenção e custo

---

#### I1. Duplicação de código ~30% nas API routes

**Evidência — auth check idêntico em 12 rotas:**
```typescript
// Repetido 12 vezes, LITERALMENTE igual:
const session = await getServerSession(authOptions);
if (!session || !session.user?.id) {
  return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
}
```

**Evidência — pagination idêntica em 3 rotas:**
```typescript
// Repetido 3 vezes, LITERALMENTE igual:
const page = Math.max(1, parseInt(searchParams.get("page") || "1"));
const limit = Math.min(50, Math.max(1, parseInt(searchParams.get("limit") || "10")));
const skip = (page - 1) * limit;
```

**Evidência — response format inconsistente (3 padrões):**
```typescript
// Padrão A: { data: result }           — 11 rotas
// Padrão B: { data, pagination }        — 3 rotas
// Padrão C: { message, id, data }       — 4 rotas
```

---

#### I2. Dois sistemas de LiveFeed duplicados

**Evidência:**

| Aspecto | Sistema 1 | Sistema 2 |
|---------|-----------|-----------|
| API | `/api/livefeed` | `/api/live-feed` |
| Page | `/livefeed` | `/live-feed` |
| Storage | `LIVEFEED.md` (arquivo markdown) | `data/live-feed.json` (JSON file) |
| Lib | Lê/escreve markdown direto | `lib/liveFeedStore.ts` |
| Polling | `setInterval(fetchFeed, 3000)` | `setInterval(fetchFeed, 4000)` |
| Modelo | Texto livre com padrão `[TIMESTAMP] [AGENT]` | Objetos tipados com `FeedKind` |

**Impacto:** Código morto, confusão, 2 sistemas fazendo polling no filesystem.

---

#### I3. Polling agressivo no filesystem (não escala)

**Evidência:**
```typescript
// livefeed/page.tsx line 84:
intervalRef.current = setInterval(fetchFeed, 3000);  // A cada 3 SEGUNDOS

// live-feed/page.tsx line 27:
const REFRESH_MS = 4000;  // A cada 4 SEGUNDOS
```

Cada tab aberta = 1 request HTTP a cada 3-4 segundos → 1 leitura de arquivo no servidor.
Com 50 tabs abertas = 15 leituras de arquivo/segundo.
**File I/O não escala horizontalmente.**

---

#### I4. Sem formato de resposta padronizado e sem error codes

**Evidência:**
```typescript
// Erros genéricos sem código:
return NextResponse.json({ error: "Failed to fetch tournament" }, { status: 500 });
return NextResponse.json({ error: "Tournament not found" }, { status: 404 });
return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

// vs. como deveria ser:
return NextResponse.json({
  success: false,
  error: { code: "TOURNAMENT_NOT_FOUND", message: "Tournament not found" }
}, { status: 404 });
```

---

#### I5. Types monolítico — 322 linhas, 39 interfaces num arquivo só

**Evidência:** `src/types/index.ts` — 322 linhas contendo:
- 5 enums (que ninguém usa)
- 22 interfaces (User, Tournament, Game, Group, Standing, Bracket, etc)
- 12 tipos auxiliares (inputs, options, filters)
- Tudo no mesmo arquivo

Com multi-categoria, vai para 700+ linhas num arquivo só.

---

#### I6. Zero shared UI components (botões, inputs, modals)

**Evidência:** Apenas 7 componentes reutilizáveis (2 layout + 5 tournament-specific).
Todos os botões, inputs, selects, modais, cards, spinners, error messages são **inline** nos 16 page.tsx, com estilos Tailwind duplicados.

```typescript
// Este padrão aparece em 12+ páginas:
<button className="px-6 py-3 bg-blue-600 text-white rounded-lg font-semibold
  hover:bg-blue-700 transition disabled:opacity-50 disabled:cursor-not-allowed">
```

---

### 🟢 MENORES — Boas práticas a adotar

| # | Item |
|---|------|
| M1 | Sem Docker/CI/CD |
| M2 | Sem health check endpoint |
| M3 | Sem validação de env vars (se `DATABASE_URL` faltar, crash sem mensagem clara) |
| M4 | `prisma db push` em vez de migrations (destrutivo em produção) |
| M5 | `@types/bcryptjs` e `@types/uuid` em `dependencies` ao invés de `devDependencies` |
| M6 | Dead links no Footer (`href="#"` em Privacy, Terms, Contact, About) |

---

## 3. Estrutura Modular Proposta

### Princípio: Feature-First Modular Monolith

Cada domínio de negócio vive em seu próprio módulo **auto-contido**, com seus types, services, e schemas. Mudanças num módulo **não afetam** outros.

```
src/
├── modules/                              ← UM DIRETÓRIO POR DOMÍNIO
│   ├── auth/
│   │   ├── auth.service.ts
│   │   ├── auth.types.ts
│   │   └── auth.schemas.ts
│   │
│   ├── tournament/
│   │   ├── tournament.service.ts         ← Business logic
│   │   ├── tournament.repository.ts      ← Prisma queries isoladas
│   │   ├── tournament.types.ts           ← Types do domínio
│   │   ├── tournament.schemas.ts         ← Zod validation
│   │   ├── tournament.constants.ts       ← Defaults, status values
│   │   └── __tests__/
│   │       ├── tournament.service.test.ts
│   │       └── tournament.repository.test.ts
│   │
│   ├── category/
│   │   ├── category.service.ts
│   │   ├── category.repository.ts
│   │   ├── category.types.ts
│   │   ├── category.schemas.ts
│   │   ├── template.service.ts           ← Templates TAFC/LBF/NFA
│   │   ├── qualifier-chain.service.ts    ← Qualify → Pro
│   │   ├── templates/
│   │   │   ├── tafc-strict.ts
│   │   │   ├── lbf-stage.ts
│   │   │   ├── nfa-open.ts
│   │   │   └── simple.ts
│   │   └── __tests__/
│   │
│   ├── registration/
│   │   ├── registration.service.ts       ← Inscrição de dupla
│   │   ├── registration.repository.ts
│   │   ├── multi-category.policy.ts      ← Validação de multi-categoria
│   │   ├── level-review.service.ts       ← Workflow de revisão técnica
│   │   ├── waitlist.service.ts           ← Lista de espera
│   │   ├── registration.types.ts
│   │   ├── registration.schemas.ts
│   │   └── __tests__/
│   │
│   ├── scheduling/
│   │   ├── scheduling.service.ts         ← Orquestrador
│   │   ├── generators/
│   │   │   ├── bracket.generator.ts      ← Bracket eliminatório
│   │   │   ├── group.generator.ts        ← Fase de grupos
│   │   │   ├── kotb.generator.ts         ← King of the Beach
│   │   │   └── round-robin.generator.ts  ← Round Robin
│   │   ├── slot-allocator.ts             ← ScheduleSlot por quadra/dia
│   │   ├── scheduling.types.ts
│   │   └── __tests__/
│   │       ├── bracket.generator.test.ts
│   │       ├── kotb.generator.test.ts
│   │       └── round-robin.generator.test.ts
│   │
│   ├── game/
│   │   ├── game.service.ts
│   │   ├── game.repository.ts
│   │   ├── score.validator.ts            ← Best-of-3, deuce, win-by-2
│   │   ├── game.types.ts
│   │   ├── game.schemas.ts
│   │   └── __tests__/
│   │
│   ├── payment/
│   │   ├── order.service.ts
│   │   ├── payment.service.ts
│   │   ├── refund.service.ts
│   │   ├── gateways/
│   │   │   ├── gateway.interface.ts      ← Contrato genérico
│   │   │   ├── stripe.gateway.ts
│   │   │   └── mercadopago.gateway.ts
│   │   ├── webhooks/
│   │   │   ├── stripe.webhook.ts
│   │   │   └── mercadopago.webhook.ts
│   │   ├── payment.types.ts
│   │   └── __tests__/
│   │
│   ├── checkin/
│   │   ├── checkin.service.ts
│   │   ├── qr.service.ts
│   │   ├── kit.service.ts
│   │   ├── checkin.types.ts
│   │   └── __tests__/
│   │
│   ├── athlete/
│   │   ├── athlete.service.ts
│   │   ├── athlete.repository.ts
│   │   ├── athlete.types.ts
│   │   └── __tests__/
│   │
│   ├── ranking/
│   │   ├── ranking.service.ts
│   │   ├── ranking.types.ts
│   │   └── __tests__/
│   │
│   └── reporting/
│       ├── report.service.ts
│       ├── export.service.ts             ← CSV/XLSX
│       └── report.types.ts
│
├── shared/                               ← CÓDIGO COMPARTILHADO
│   ├── database/
│   │   ├── prisma.ts                     ← Singleton (ex lib/db.ts)
│   │   └── transaction.ts               ← withTransaction() helper
│   ├── middleware/
│   │   ├── with-auth.ts                  ← Extraído das 12 rotas
│   │   ├── with-organizer.ts             ← Verifica ownership
│   │   └── with-validation.ts            ← Zod validation middleware
│   ├── api/
│   │   ├── response.ts                   ← apiSuccess, apiError, apiPaginated
│   │   ├── errors.ts                     ← NotFoundError, ForbiddenError, etc
│   │   └── pagination.ts                 ← parsePagination() helper
│   ├── audit/
│   │   └── audit.service.ts
│   ├── config/
│   │   ├── env.ts                        ← Validação de env vars com Zod
│   │   └── constants.ts                  ← Magic numbers centralizados
│   └── types/
│       └── common.ts                     ← PaginatedResult, ApiResponse, etc
│
├── components/                           ← UI COMPONENTS
│   ├── ui/                               ← Design system atômico
│   │   ├── Button.tsx
│   │   ├── Input.tsx
│   │   ├── Select.tsx
│   │   ├── Modal.tsx
│   │   ├── Card.tsx
│   │   ├── Badge.tsx
│   │   ├── Tabs.tsx
│   │   ├── DataTable.tsx
│   │   ├── ProgressBar.tsx
│   │   ├── EmptyState.tsx
│   │   ├── LoadingSpinner.tsx
│   │   ├── ErrorMessage.tsx
│   │   └── index.ts                     ← Barrel export
│   ├── layout/
│   │   ├── Navbar.tsx
│   │   ├── Footer.tsx
│   │   └── PageLayout.tsx
│   ├── tournament/                       ← Existentes, refatorados
│   │   ├── BracketView.tsx
│   │   ├── GroupStageView.tsx
│   │   ├── RoundRobinView.tsx
│   │   ├── MatchCard.tsx
│   │   ├── CategorySelector.tsx          ← NOVO
│   │   └── CategoryProgress.tsx          ← NOVO
│   ├── registration/                     ← NOVO
│   │   ├── TeamRegistrationForm.tsx
│   │   ├── PartnerSearch.tsx
│   │   └── PricingLotCard.tsx
│   └── checkin/                          ← NOVO
│       ├── QrScanner.tsx
│       └── CheckinCard.tsx
│
├── hooks/                                ← React hooks compartilhados
│   ├── use-auth.ts
│   ├── use-fetch.ts                      ← SWR wrapper
│   ├── use-pagination.ts
│   └── use-debounce.ts
│
├── app/                                  ← PAGES + API ROUTES (THIN)
│   ├── api/                              ← Routes finas — delegam para services
│   │   ├── auth/...
│   │   ├── tournaments/
│   │   │   ├── route.ts                  ← ~25 linhas (não 178)
│   │   │   └── [id]/
│   │   │       ├── route.ts             ← ~25 linhas (não 237)
│   │   │       ├── generate/route.ts    ← ~20 linhas (não 244)
│   │   │       └── categories/route.ts  ← NOVO
│   │   ├── games/[id]/route.ts          ← ~20 linhas (não 264)
│   │   ├── payments/                    ← NOVO
│   │   ├── checkin/                     ← NOVO
│   │   └── reports/                     ← NOVO
│   │
│   ├── (public)/                        ← Layout público
│   │   ├── page.tsx                     ← Home
│   │   ├── login/page.tsx
│   │   ├── register/page.tsx
│   │   └── events/[id]/page.tsx         ← Página pública do evento
│   │
│   └── (dashboard)/                     ← Layout autenticado
│       ├── layout.tsx
│       ├── dashboard/page.tsx
│       ├── profile/page.tsx
│       ├── tournaments/...
│       ├── athletes/...
│       └── rankings/page.tsx
│
└── prisma/
    ├── schema.prisma
    ├── migrations/                      ← Migrations versionadas (não db push)
    └── seed.ts
```

---

## 4. Padrões e Convenções

### 4.1 API Route Thin Pattern

```
ANTES: api/tournaments/[id]/route.ts = 237 linhas
  ├── Session check (6 linhas)
  ├── Prisma query com 20 linhas de includes
  ├── Business logic (30 linhas)
  ├── Error handling (15 linhas)
  └── Response formatting (5 linhas)

DEPOIS: api/tournaments/[id]/route.ts = ~25 linhas
  ├── Middleware handles auth, validation
  ├── Delega para TournamentService
  └── Resposta padronizada
```

**Exemplo concreto:**

```typescript
// app/api/tournaments/[id]/route.ts — NOVA versão (~25 linhas)
import { NextRequest } from 'next/server';
import { TournamentService } from '@/modules/tournament/tournament.service';
import { updateTournamentSchema } from '@/modules/tournament/tournament.schemas';
import { withAuth } from '@/shared/middleware/with-auth';
import { withValidation } from '@/shared/middleware/with-validation';
import { apiSuccess, apiError } from '@/shared/api/response';

export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const tournament = await TournamentService.getById(params.id);
    return apiSuccess(tournament);
  } catch (error) {
    return apiError(error);
  }
}

export const PUT = withAuth(
  withValidation(updateTournamentSchema, async (req, { data, session, params }) => {
    const tournament = await TournamentService.update(params.id, data, session.user.id);
    return apiSuccess(tournament);
  })
);

export const DELETE = withAuth(async (req, { session, params }) => {
  await TournamentService.delete(params.id, session.user.id);
  return apiSuccess({ deleted: true });
});
```

### 4.2 Middleware Composable (elimina duplicação)

```typescript
// shared/middleware/with-auth.ts
import { getServerSession } from 'next-auth';
import { authOptions } from '@/modules/auth/auth.service';
import { apiError } from '@/shared/api/response';
import { AppError } from '@/shared/api/errors';

type AuthenticatedHandler = (
  req: NextRequest,
  context: { session: AuthSession; params?: Record<string, string> }
) => Promise<NextResponse>;

export function withAuth(handler: AuthenticatedHandler) {
  return async (req: NextRequest, ctx?: { params: Record<string, string> }) => {
    try {
      const session = await getServerSession(authOptions);
      if (!session?.user?.id) {
        throw new AppError('UNAUTHORIZED', 'Authentication required', 401);
      }
      return handler(req, { session, params: ctx?.params });
    } catch (error) {
      return apiError(error);
    }
  };
}
```

**Impacto:** 12 blocos de 6 linhas cada (72 linhas) → 1 middleware de 20 linhas.

### 4.3 Response Padronizado

```typescript
// shared/api/response.ts

// ── Sucesso ──
export function apiSuccess<T>(data: T, status = 200) {
  return NextResponse.json({ success: true, data }, { status });
}

export function apiPaginated<T>(data: T[], meta: PaginationMeta) {
  return NextResponse.json({ success: true, data, meta });
}

// ── Erro ──
export function apiError(error: unknown) {
  if (error instanceof AppError) {
    return NextResponse.json(
      { success: false, error: { code: error.code, message: error.message, details: error.details } },
      { status: error.statusCode }
    );
  }
  console.error('Unexpected error:', error);
  return NextResponse.json(
    { success: false, error: { code: 'INTERNAL_ERROR', message: 'Internal server error' } },
    { status: 500 }
  );
}
```

```typescript
// shared/api/errors.ts

export class AppError extends Error {
  constructor(
    public code: string,
    message: string,
    public statusCode: number = 500,
    public details?: unknown,
  ) {
    super(message);
  }
}

export class NotFoundError extends AppError {
  constructor(entity: string) {
    super(`${entity.toUpperCase()}_NOT_FOUND`, `${entity} not found`, 404);
  }
}

export class ForbiddenError extends AppError {
  constructor(reason = 'Insufficient permissions') {
    super('FORBIDDEN', reason, 403);
  }
}

export class ConflictError extends AppError {
  constructor(reason: string) {
    super('CONFLICT', reason, 409);
  }
}

export class PolicyViolationError extends AppError {
  constructor(reason: string) {
    super('POLICY_VIOLATION', reason, 422);
  }
}
```

### 4.4 Transações Seguras

```typescript
// shared/database/transaction.ts
import { prisma } from './prisma';
import type { PrismaClient } from '@prisma/client';

type TransactionClient = Parameters<Parameters<PrismaClient['$transaction']>[0]>[0];

export async function withTransaction<T>(
  fn: (tx: TransactionClient) => Promise<T>
): Promise<T> {
  return prisma.$transaction(fn, {
    maxWait: 5000,
    timeout: 10000,
  });
}
```

**Uso — geração de torneio (ANTES vs DEPOIS):**
```typescript
// ANTES: 20+ operações separadas, sem rollback
await prisma.game.deleteMany(...);
await prisma.round.deleteMany(...);
await prisma.group.deleteMany(...);
// ... N creates em loops ...

// DEPOIS: tudo atômico
await withTransaction(async (tx) => {
  await tx.game.deleteMany({ where: { categoryId } });
  await tx.round.deleteMany({ where: { categoryId } });
  await tx.group.deleteMany({ where: { categoryId } });
  // ... creates usam `tx` ao invés de `prisma` ...
  // Se qualquer operação falhar → TUDO reverte
});
```

### 4.5 Types Unificados — Gerados do Prisma + Zod

```typescript
// ANTES: src/types/index.ts — 322 linhas, enums desconectados do runtime
export enum TournamentStatus {
  DRAFT = 'DRAFT',                    // ← NUNCA USADO
  REGISTRATION_OPEN = 'REGISTRATION_OPEN', // ← NUNCA USADO
}

// DEPOIS: cada módulo tem seus types derivados do Prisma
// modules/tournament/tournament.types.ts

import type { Tournament as PrismaTournament } from '@prisma/client';

// Status values reais (single source of truth)
export const TOURNAMENT_STATUS = {
  DRAFT: 'draft',
  REGISTRATION: 'registration',
  IN_PROGRESS: 'in_progress',
  COMPLETED: 'completed',
  CANCELLED: 'cancelled',
} as const;

export type TournamentStatus = typeof TOURNAMENT_STATUS[keyof typeof TOURNAMENT_STATUS];

// Type do Prisma + extensions
export type Tournament = PrismaTournament & {
  organizer: { id: string; name: string; email: string };
  categories?: CategorySummary[];
};

// Input types derivados do Zod schema
export type CreateTournamentInput = z.infer<typeof createTournamentSchema>;
export type UpdateTournamentInput = z.infer<typeof updateTournamentSchema>;
```

**Impacto:**
- 1 source of truth para status/format values
- Types sempre em sync com o banco (derivados do Prisma)
- Input types sempre em sync com validação (derivados do Zod)
- `src/types/index.ts` legado → deletado gradualmente

### 4.6 Validação de Env Vars

```typescript
// shared/config/env.ts
import { z } from 'zod';

const envSchema = z.object({
  DATABASE_URL: z.string().url('DATABASE_URL must be a valid URL'),
  NEXTAUTH_SECRET: z.string().min(16, 'NEXTAUTH_SECRET must be at least 16 chars'),
  NEXTAUTH_URL: z.string().url(),
  GOOGLE_CLIENT_ID: z.string().optional(),
  GOOGLE_CLIENT_SECRET: z.string().optional(),
  STRIPE_SECRET_KEY: z.string().optional(),
  STRIPE_WEBHOOK_SECRET: z.string().optional(),
});

export const env = envSchema.parse(process.env);

// Se DATABASE_URL falta → erro claro na inicialização, não crash misterioso
```

---

## 5. Escalabilidade e Performance

### 5.1 Rendering Strategy por Página

| Página | Tipo | Caching | Razão |
|--------|------|---------|-------|
| Home (`/`) | SSG | Build-time | Conteúdo estático |
| Evento público (`/events/[id]`) | ISR | revalidate: 60s | Muda pouco, muitas views |
| Rankings | ISR | revalidate: 300s | Muda pouco |
| Lista de torneios | ISR | revalidate: 120s | Muda pouco |
| Dashboard | CSR | SWR client-side | Personalizado por user |
| Manage scores | CSR | Sem cache | Tempo real |
| Check-in scanner | CSR | Sem cache | Tempo real |
| Create tournament | CSR | N/A | Formulário |

### 5.2 Database Performance

```
1. Connection Pooling
   → PlanetScale (serverless MySQL, pool automático)
   → ou PgBouncer (se self-hosted)

2. Índices compostos para queries críticas:
   @@index([tournamentId, status])     // jogos em andamento
   @@index([categoryId, status])       // inscrições por categoria
   @@index([userId, status])           // minhas inscrições

3. Select otimizado (não carregar tudo):
   ANTES: include com 5 níveis de nesting em todas rotas
   DEPOIS: repository com includes mínimos por use-case

4. Paginação real (já existe parcialmente, expandir para jogos/inscrições)

5. Migrations versionadas:
   ANTES: prisma db push (pode destruir dados)
   DEPOIS: prisma migrate dev/deploy (versionado, reversível)
```

### 5.3 Frontend Performance

```
1. Code splitting automático (Next.js já faz por page)

2. Lazy loading de componentes pesados:
   const BracketView = dynamic(() => import('@/components/tournament/BracketView'));
   const RechartsDashboard = dynamic(() => import('@/components/dashboard/Charts'));

3. SWR para data fetching (elimina useEffect + useState boilerplate):
   ANTES: 15 linhas de useEffect + loading + error + state
   DEPOIS: const { data, isLoading } = useFetch('/api/tournaments')

4. Image optimization (next/image) para banners de eventos

5. Bundle analysis: adicionar @next/bundle-analyzer para monitorar tamanho
```

### 5.4 Substituir Polling por Abordagens Eficientes

```
LiveFeed (agent coordination):
  ANTES: setInterval(fetch, 3000) — file I/O a cada 3 segundos
  DEPOIS: Server-Sent Events (SSE) — push quando há novidade
  → OU: simplesmente eliminar (é ferramenta de dev, não de produção)

Scores ao vivo (dia de torneio):
  → SSE endpoint: /api/tournaments/[id]/live
  → Apenas quando há jogo em andamento
  → Client conecta uma vez, servidor envia updates

Restante do app:
  → SWR com revalidateOnFocus: true (revalida ao voltar para a tab)
  → Sem polling
```

---

## 6. Trabalho Paralelo Multi-Dev/AI

### 6.1 O Problema Hoje

```
Probabilidade de conflito de merge ao trabalhar em paralelo:

ARQUIVO                              LINHAS    P(CONFLITO)
tournaments/[id]/page.tsx            595       ████████████ 95%
tournaments/[id]/manage/page.tsx     599       ████████████ 95%
tournaments/create/page.tsx          519       ██████████░░ 90%
api/tournaments/[id]/route.ts        237       ████████░░░░ 80%
api/tournaments/[id]/generate/route.ts 244     ████████░░░░ 80%
lib/scheduling.ts                    217       ████████░░░░ 80%
types/index.ts                       322       ██████████░░ 90%
```

### 6.2 A Solução: Módulos Isolados

```
Probabilidade de conflito DEPOIS da reestruturação:

MÓDULO                    RESPONSÁVEL     P(CONFLITO c/ outro módulo)
modules/tournament/       Dev/Agent A     ░░░░░░░░░░░░ ~5%
modules/category/         Dev/Agent B     ░░░░░░░░░░░░ ~5%
modules/scheduling/       Dev/Agent C     ░░░░░░░░░░░░ ~5%
modules/registration/     Dev/Agent D     ░░░░░░░░░░░░ ~5%
modules/payment/          Dev/Agent E     ░░░░░░░░░░░░ ~5%
modules/checkin/          Dev/Agent F     ░░░░░░░░░░░░ ~5%
shared/                   Core team       ██░░░░░░░░░░ ~15% (todos usam)
```

**5% de conflito** vs. **95% de conflito**. Esse é o ganho real da modularização.

### 6.3 Governança para Multi-Dev/AI (Recomendação Codex)

```
1. CODEOWNERS por módulo:
   modules/tournament/  → @dev-a
   modules/payment/     → @dev-e
   shared/              → @core-team (PR review obrigatório)

2. Feature flags para entregas incrementais:
   // shared/config/features.ts
   export const FEATURES = {
     MULTI_CATEGORY: process.env.FF_MULTI_CATEGORY === 'true',
     PAYMENTS: process.env.FF_PAYMENTS === 'true',
     CHECKIN: process.env.FF_CHECKIN === 'true',
   };

   // Permite deployar código novo sem ativar em produção
   if (FEATURES.MULTI_CATEGORY) {
     // Mostra seletor de categorias
   }

3. ADRs (Architecture Decision Records) curtas por módulo:
   modules/payment/ADR-001-gateway-abstraction.md
   → "Por que criamos interface genérica ao invés de Stripe direto"

4. Contratos de API via Zod schemas:
   → Frontend e backend usam o MESMO schema
   → Mudança no schema = TypeScript error nos dois lados
```

### 6.4 Testes como Rede de Segurança

```
Prioridade de testes para proteção contra regressão:

1. Unit tests (pure business logic — rápido, sem DB):
   modules/scheduling/generators/*.test.ts
   modules/game/score.validator.test.ts
   modules/registration/multi-category.policy.test.ts

2. Integration tests (com DB mockada):
   modules/tournament/tournament.service.test.ts
   modules/registration/registration.service.test.ts

3. Contract tests (API → Frontend):
   Zod schemas shared entre ambos os lados

Setup mínimo:
  npm install -D vitest @vitest/coverage-v8
  vitest.config.ts com aliases @/modules/*, @/shared/*
```

---

## 7. Infraestrutura de Baixo Custo

### 7.1 Stack Recomendada

```
                    ┌─────────────┐
                    │  Cloudflare  │  CDN + DDoS (GRÁTIS)
                    │  (free tier) │
                    └──────┬──────┘
                           │
                    ┌──────┴──────┐
                    │   Vercel    │  Next.js hosting ($20/mês pro)
                    │  serverless │  Auto-scale, zero-config deploy
                    └──────┬──────┘
                           │
              ┌────────────┼────────────┐
              │            │            │
        ┌─────┴─────┐ ┌───┴───┐ ┌─────┴─────┐
        │ PlanetScale│ │Upstash│ │Cloudflare │
        │  MySQL     │ │ Redis │ │    R2     │
        │  $0-29/mês │ │ $0-10 │ │  storage  │
        │  serverless│ │ cache │ │  $0-5/mês │
        └───────────┘ └───────┘ └───────────┘
```

### 7.2 Comparativo de Custo

| Cenário | EC2/VPS (atual) | Serverless (proposto) |
|---------|-----------------|------------------------|
| Desenvolvimento | $15-50/mês | **$0-20/mês** |
| 100 users/mês | $30-50/mês | **$20-30/mês** |
| 1.000 users/mês | $50-100/mês | **$20-50/mês** |
| 10.000 users/mês | $150-300/mês | **$50-100/mês** |
| Pico (dia de torneio) | Precisa resize manual | **Auto-scale** |
| Ocioso (madrugada) | Paga igual | **$0 (sem uso = sem custo)** |

**Para um app de torneios (picos no fim de semana, ocioso na semana), serverless economiza 50-70%.**

### 7.3 Otimizações de Custo

```
1. ISR/SSG onde possível → reduz compute (serverless functions)
2. Cloudflare CDN grátis → reduz bandwidth
3. Connection pooling → reduz conexões ao banco
4. Lazy loading → reduz bundle size
5. next/image → otimização automática de imagens
6. Webhook idempotent → evita processamento duplicado ($)
```

---

## 8. Plano de Migração Incremental

### Princípio: Cada step é deployável. Zero big-bang.

---

### Step 0 — Setup (0.5 dia)

```
□ Instalar: vitest, swr
□ Criar pastas: src/modules/, src/shared/, src/hooks/
□ Configurar path aliases em tsconfig.json:
    "@/modules/*": ["./src/modules/*"]
    "@/shared/*": ["./src/shared/*"]
    "@/hooks/*": ["./src/hooks/*"]
□ Mudar de prisma db push → prisma migrate dev (criar baseline migration)
□ Criar vitest.config.ts
```

### Step 1 — Shared Layer (1.5 dia)

```
□ shared/database/prisma.ts ← mover de lib/db.ts
□ shared/database/transaction.ts ← novo
□ shared/api/response.ts ← novo (apiSuccess, apiError, apiPaginated)
□ shared/api/errors.ts ← novo (AppError, NotFoundError, ForbiddenError, etc)
□ shared/api/pagination.ts ← extrair de 3 routes
□ shared/middleware/with-auth.ts ← extrair de 12 routes
□ shared/middleware/with-validation.ts ← novo
□ shared/config/env.ts ← novo (validação com Zod)
□ shared/config/constants.ts ← centralizar magic numbers
□ shared/audit/audit.service.ts ← novo
✅ TESTAR: importar de shared/ funciona com aliases
```

### Step 2 — Módulo tournament (1.5 dia)

```
□ modules/tournament/tournament.types.ts ← extrair types relevantes
□ modules/tournament/tournament.constants.ts ← status, format values
□ modules/tournament/tournament.schemas.ts ← extrair Zod schemas
□ modules/tournament/tournament.repository.ts ← extrair Prisma queries
□ modules/tournament/tournament.service.ts ← extrair business logic
□ Refatorar api/tournaments/route.ts para usar TournamentService
□ Refatorar api/tournaments/[id]/route.ts
□ PRIMEIRO TESTE: tournament.service.test.ts
✅ TESTAR: CRUD de torneio funciona igual ao antes
```

### Step 3 — Módulos game + scheduling (2 dias)

```
□ modules/game/ ← extrair de api/games/ + score validation
□ modules/scheduling/ ← extrair de lib/scheduling.ts + lib/kotb.ts + lib/bracketUtils.ts
   □ scheduling/generators/bracket.generator.ts
   □ scheduling/generators/group.generator.ts
   □ scheduling/generators/kotb.generator.ts
   □ scheduling/generators/round-robin.generator.ts
□ Adicionar withTransaction() na geração de torneio
□ TESTES: bracket.generator.test.ts, kotb.generator.test.ts, score.validator.test.ts
✅ TESTAR: geração de brackets/grupos/KOTB funciona igual
```

### Step 4 — Módulos athlete + ranking + auth (1 dia)

```
□ modules/athlete/ ← extrair de api/athletes/
□ modules/ranking/ ← extrair de api/rankings/
□ modules/auth/ ← mover de lib/auth.ts
✅ TESTAR: login, registro, rankings, perfil de atleta funcionam
```

### Step 5 — Componentes UI + hooks (1.5 dia)

```
□ components/ui/ (Button, Input, Select, Modal, Card, Badge, LoadingSpinner, ErrorMessage)
□ hooks/use-fetch.ts (SWR wrapper)
□ hooks/use-pagination.ts
□ Refatorar 2-3 pages para usar novos componentes (proof of concept)
✅ TESTAR: pages refatoradas renderizam corretamente
```

### Step 6 — Limpar tipos legados + livefeed duplicado (1 dia)

```
□ Deletar enums não usados de types/index.ts
□ Mover interfaces necessárias para respectivos módulos
□ Decidir: manter 1 livefeed ou nenhum (é ferramenta de dev)
□ Deletar o que sobrar
□ Mover @types/* para devDependencies
✅ TESTAR: npx tsc --noEmit → zero errors
```

---

### Timeline Total: ~9 dias de trabalho

```
Step 0: 0.5 dia  ██
Step 1: 1.5 dias ██████
Step 2: 1.5 dias ██████
Step 3: 2.0 dias ████████
Step 4: 1.0 dia  ████
Step 5: 1.5 dias ██████
Step 6: 1.0 dia  ████
                 ────────────────
Total:  9 dias (~2 semanas com buffer)
```

**Depois: novos módulos (category, registration, payment, checkin, reporting) são implementados JÁ na nova estrutura, sem reestruturação adicional.**

---

## Resumo: Antes vs. Depois

| Métrica | Hoje | Reestruturado |
|---------|------|---------------|
| **Maior API route** | 264 linhas | ~25 linhas |
| **Maior page component** | 599 linhas | ~150 linhas (composição) |
| **Business logic em routes** | 78% inline | 0% (tudo em services) |
| **Transações no DB** | 0 | 100% onde necessário |
| **Código duplicado** | ~30% | <5% (middleware/helpers) |
| **Padrões de response** | 3 diferentes | 1 padronizado |
| **Status values** | 3 sistemas paralelos | 1 source of truth |
| **Componentes reutilizáveis** | 7 | 30+ |
| **Testes** | 0 | Core business logic coberta |
| **P(conflito merge)** | ~95% | ~5% |
| **Tempo para add novo gateway** | Editar payment monolito | Criar 1 arquivo |
| **Custo infra** | $50-100/mês | $20-84/mês |
| **Deploy** | Manual (SSH) | `git push` (auto) |
